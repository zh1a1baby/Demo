//
//  MoreTableViewCell.h
//  SDTTinyWarmHeart
//
//  Created by mac on 16/5/24.
//  Copyright © 2016年 mac. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Model.h"

@interface MoreTableViewCell : UITableViewCell


@property (weak, nonatomic) IBOutlet UILabel *themeLabel;

@property (weak, nonatomic) IBOutlet ThemeImageView *imageTheme;

@property (weak, nonatomic) IBOutlet UILabel *labelTheme;

//@property(strong,nonatomic)Model *model;


@end
