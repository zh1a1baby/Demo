//
//  PushViewController.h
//  SDTTinyWarmHeart
//
//  Created by mac on 16/5/24.
//  Copyright © 2016年 mac. All rights reserved.
//

#import "BaseViewController.h"

@interface PushViewController : BaseViewController

//@property(strong,nonatomic)ThemeImageView *



@end
