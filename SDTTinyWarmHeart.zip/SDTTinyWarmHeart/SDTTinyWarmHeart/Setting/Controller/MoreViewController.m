//
//  MoreViewController.m
//  SDTTinyWarmHeart
//
//  Created by mac on 16/5/21.
//  Copyright © 2016年 mac. All rights reserved.
//

#import "MoreViewController.h"
#import "MoreTableViewCell.h"
#import "PushViewController.h"
#define  CellID @"CellID"
@interface MoreViewController ()<UITableViewDataSource,UITableViewDelegate>{

    NSArray *_arr;
    UITableView *_table;
    
    
    
}

@end

@implementation MoreViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    [self tableViewCtl];

}


-(void)tableViewCtl{

    //创建表示图
    _table = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, KScreenWidth, KScreenHeight - KtabBarHeight - kTabBarHeight)];
    
    [self.view addSubview:_table];
    _table.dataSource = self;
    _table.delegate = self;
    
    //注册单元格
//    [_table registerNib:[UINib nibWithNibName:@"MoreTableViewCell" bundle:[NSBundle mainBundle]] forCellReuseIdentifier:CellID];
//    [_table registerClass:[MoreTableViewCell class] forCellReuseIdentifier:CellID];
    
    _arr = @[@"主题",@"个人中心",@"清除缓存",@"通用设置",@"关于微博"];

//    [_table reloadData];
    _table.backgroundColor = [UIColor clearColor];
    
    
    
    

    
}

#pragma mark --- 代理方法
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{



    return _arr.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{

    
    MoreTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellID];
    if (cell == nil) {
        cell = [[[NSBundle mainBundle]loadNibNamed:@"MoreTableViewCell" owner:self options:nil] lastObject];
    }
    
    NSString *str = _arr[indexPath.row];
    cell.themeLabel.text = str;
    cell.backgroundColor = [UIColor clearColor];
    if (indexPath.row == 0) {
        cell.imageTheme.imageName = @"more_icon_theme.png";
    }else if(indexPath.row == 1){
    
        cell.imageTheme.imageName = @"more_icon_account";
    
    }else if(indexPath.row == 2){
    
     cell.imageTheme.imageName = @"more_icon_draft";
    
    }else if(indexPath.row == 3){
        
        cell.imageTheme.imageName = @"more_icon_feedback";
        
    }else if(indexPath.row == 4){
        
        cell.imageTheme.imageName = @"more_icon_about";
        
    }
    if (indexPath.row == 0) {
        
        id themeName =  [[NSUserDefaults standardUserDefaults]objectForKey:kThemeNameUserDefaults];
        
        cell.labelTheme.text = themeName;
    
    }
   
    
//    _imageTheme.imageName = @"more_icon_theme";
//    _imageTheme.imageName = @"more_icon_draft";
//    _imageTheme.imageName = @"more_icon_theme.png";
    return cell;
}

//单元格高度
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{


    return 80;

}

//当单元格被点击的时候,
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    //当被点击的单元格为0的时候Push到另一个界面
    if (indexPath.row == 0) {
        PushViewController *push = [[PushViewController alloc]init];
        
        [self.navigationController pushViewController:push animated:YES];
        
    }
    
    
    
    
}
- (void)viewWillAppear:(BOOL)animated{

    
    [_table reloadData];

}

@end
