//
//  MoreTableViewCell.m
//  SDTTinyWarmHeart
//
//  Created by mac on 16/5/24.
//  Copyright © 2016年 mac. All rights reserved.
//

#import "MoreTableViewCell.h"

@interface MoreTableViewCell ()

@end


@implementation MoreTableViewCell

-(void)awakeFromNib{
    [super awakeFromNib];
    
   
    
    
    
    
}



-(void)layoutSubviews{

    [super layoutSubviews];
    
//   id themeName =  [[NSUserDefaults standardUserDefaults]objectForKey:kThemeNameUserDefaults];
//    _labelTheme.text = themeName;


}



@end
