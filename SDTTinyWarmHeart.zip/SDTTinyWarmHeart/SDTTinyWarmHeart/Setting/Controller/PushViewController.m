//
//  PushViewController.m
//  SDTTinyWarmHeart
//
//  Created by mac on 16/5/24.
//  Copyright © 2016年 mac. All rights reserved.
//


#import "PushViewController.h"
#import "MoreTableViewCell.h"
#import "Model.h"
#define  MyCellID @"MyCellID"
@interface PushViewController ()<UITableViewDataSource,UITableViewDelegate>{

    NSArray *_TableArr;
    UITableViewCell *_cell;

}

@end

@implementation PushViewController

- (void)dealloc {

    [[NSNotificationCenter defaultCenter]removeObserver:self];

}

-(instancetype)initWithCoder:(NSCoder *)aDecoder{

    if (self = [super initWithCoder:aDecoder]) {
        [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(tableVC) name:KThemeChanged object:nil];
    }
    return self;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self tableVC];
    
}




-(void)tableVC{

    UITableView *table = [[UITableView alloc]initWithFrame:self.view.bounds];
    
    [self.view addSubview:table];
    
    table.dataSource = self;
    table.delegate = self;
    
    [table registerClass:[UITableViewCell class] forCellReuseIdentifier:MyCellID];
    table.backgroundColor = [UIColor clearColor];
    
    [self lodaData];


}

//加载数据
-(void)lodaData{

    NSString *path = [[NSBundle mainBundle]pathForResource:@"theme" ofType:@"plist"];
    
    NSDictionary *dic = [NSDictionary dictionaryWithContentsOfFile:path];
    
    _TableArr = dic.allKeys;

}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{



    return _TableArr.count;

}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{

    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:MyCellID forIndexPath:indexPath];
    
    NSString *str = _TableArr[indexPath.row];
    
    cell.textLabel.text = str;
    cell.backgroundColor = [UIColor clearColor];
    ThemeManager *manager = [ThemeManager sharedInstance];
    
    
    
    // 当单元格的字符串内容与manager的内容相同时
    if ([cell.textLabel.text isEqualToString:manager.themeName]) {
        
        cell.accessoryType = UITableViewCellAccessoryCheckmark;

    }else{
    
        cell.accessoryType = UITableViewCellAccessoryNone;
    
    
    }
    
    
    
//    Model *model = [[Model alloc]init];
    
//    model.modelStr = str;
    
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{


    ThemeManager *theme = [ThemeManager sharedInstance];
    
    theme.themeName = _TableArr[indexPath.row];
    
    
    UIImage *image = [[ThemeManager sharedInstance] getImageWithImageName:@"bg_home.jpg"];
    
    CGImageRef cgImage = CGImageCreateWithImageInRect(image.CGImage, CGRectMake(0, 0, KScreenWidth, KScreenHeight));
    
    
    
    self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageWithCGImage:cgImage]];
    
    CGImageRelease(cgImage);

    
    
//    [self.navigationController popToRootViewControllerAnimated:YES];
    
    //刷新单元格,每点击一次单元格就会刷新
    [tableView reloadData];
    

}

@end
