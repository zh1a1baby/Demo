//
//  Model.h
//  SDTTinyWarmHeart
//
//  Created by mac on 16/5/24.
//  Copyright © 2016年 mac. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Model : NSObject

//@property(copy,nonatomic)NSString *modelStr;
@end
