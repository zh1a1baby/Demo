//
//  Model.m
//  SDTTinyWarmHeart
//
//  Created by mac on 16/5/24.
//  Copyright © 2016年 mac. All rights reserved.
//

#import "Model.h"

@implementation Model

@end
