//
//  MessageModel.h
//  SDTTinyWarmHeart
//
//  Created by mac on 16/6/1.
//  Copyright © 2016年 mac. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <MapKit/MapKit.h>
#import "HomeModel.h"
@interface MessageModel : NSObject<MKAnnotation>

@property (nonatomic, readonly) CLLocationCoordinate2D coordinate;

@property (nonatomic, readonly, copy, nullable) NSString *title;
@property (nonatomic, readonly, copy, nullable) NSString *subtitle;


- (void)setCoordinate:(CLLocationCoordinate2D)newCoordinate;

//存放用户信息
@property(strong,nonnull,nonatomic)HomeModel *model;


@end
