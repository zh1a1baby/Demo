//
//  MessageModel.m
//  SDTTinyWarmHeart
//
//  Created by mac on 16/6/1.
//  Copyright © 2016年 mac. All rights reserved.
//

#import "MessageModel.h"

@implementation MessageModel

-(void)setCoordinate:(CLLocationCoordinate2D)newCoordinate{

    _coordinate = newCoordinate;

}

@end
