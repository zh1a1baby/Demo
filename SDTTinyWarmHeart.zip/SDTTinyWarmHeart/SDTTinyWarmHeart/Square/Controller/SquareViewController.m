//
//  SquareViewController.m
//  SDTTinyWarmHeart
//
//  Created by mac on 16/5/21.
//  Copyright © 2016年 mac. All rights reserved.
//

#import "SquareViewController.h"
#import "MTServicePackage.h"
#import "HomeModel.h"
#import "MessageModel.h"
#import "WeiboAnnotationView.h"
#import <MapKit/MapKit.h>
@interface SquareViewController ()<MKMapViewDelegate>{


    MKMapView *_mapView;
    
    CLLocationCoordinate2D _coordinate;//用户当前位置

}



@end

@implementation SquareViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    //创建地图
    _mapView = [[MKMapView alloc]initWithFrame:self.view.bounds];
    
    
    //允许追踪用户的位置
    _mapView.showsUserLocation = YES;
    
    //允许跟随用户的位置
    [_mapView setUserTrackingMode:MKUserTrackingModeFollow animated:YES];
    
    _mapView.delegate =self;
    
    [self.view addSubview:_mapView];
    
    
    
    

}
//获取用户位置
- (void)mapView:(MKMapView *)mapView
didUpdateUserLocation:(MKUserLocation *)userLocation{
    
    
    _coordinate = userLocation.coordinate;
    
    [self loadData];
    
}


//发送请求 获取周边用户的经纬度坐标
-(void)loadData{

    NSMutableDictionary *params = nil;
    
    if (_coordinate.longitude != 0) {
        
        //计算纬度坐标
        params = [NSMutableDictionary dictionaryWithDictionary:
                  @{@"lat" :[NSString stringWithFormat:@"%lf",_coordinate.latitude],
                    @"long":[NSString stringWithFormat:@"%lf",_coordinate.longitude]
                                                                 }];
        
    
    }
    
    //发送请求 获取周围用户微博信息
    
    [MTServicePackage
       GEtWithStringURL:@"https://api.weibo.com/2/place/nearby_timeline.json"
                 params:params
            headrfields:nil
        CompletionBlock:^(id data) {
            
            NSArray *array = [data objectForKey:@"statuses"];
            
            for (NSDictionary *dic in array) {
               
                //将信息转化为model储存
                HomeModel *model = [[HomeModel alloc]initWithDataDic:dic];
                
                NSDictionary *geoDic =model.geo;
                
                NSArray *coorArr = geoDic[@"coordinates"];
                
                // 如果获取不到周围用户的坐标就返回
                if (!coorArr.count) {
                    
                    return ;
                }
                
                //纬度,经度
                CLLocationDegrees degrees = [coorArr[0] doubleValue];
                CLLocationDegrees longi = [coorArr[1] doubleValue];
                
                CLLocationCoordinate2D coordinate =CLLocationCoordinate2DMake(degrees, longi);
                
                MessageModel *annotation = [[MessageModel alloc]init];
                
                [annotation setCoordinate:coordinate];
                annotation.model = model;
                
                //往地图上添加大头针
                [_mapView addAnnotation:annotation];
                
                
            }
    }];

}
-(MKAnnotationView *)mapView:(MKMapView *)mapView viewForAnnotation:(id<MKAnnotation>)annotation{

    if([annotation isKindOfClass:[MKUserLocation class]]){
    
        return nil;
    }

    static NSString *str = @"Annotation_ID_Weibo";
    
    WeiboAnnotationView *annoView = (WeiboAnnotationView *)[mapView dequeueReusableAnnotationViewWithIdentifier:str];
    
    if (!annoView) {
        annoView = [[WeiboAnnotationView alloc]initWithAnnotation:annotation reuseIdentifier:str];
    }
    
    annoView.annotation = annotation;
    
    return annoView;
    
}



@end
