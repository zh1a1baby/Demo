//
//  WeiboAnnotationView.h
//  SDTTinyWarmHeart
//
//  Created by mac on 16/6/1.
//  Copyright © 2016年 mac. All rights reserved.
//

#import <MapKit/MapKit.h>

@interface WeiboAnnotationView : MKAnnotationView{

    UIImageView *sdtUseImagerView;//头像
    UIImageView *sdtWeiboImageVeiw;//微博图片
    UILabel *sdtTextLabel;//微博内容



}


@end
