//
//  WeiboAnnotationView.m
//  SDTTinyWarmHeart
//
//  Created by mac on 16/6/1.
//  Copyright © 2016年 mac. All rights reserved.
//

#import "WeiboAnnotationView.h"
#import "MessageModel.h"
#import "HomeModel.h"
#import "UserModel.h"
#import "UIImageView+WebCache.h"
#import "UIViewExt.h"
@implementation WeiboAnnotationView


-(instancetype)initWithAnnotation:(id<MKAnnotation>)annotation reuseIdentifier:(NSString *)reuseIdentifier{

    self = [super initWithAnnotation:annotation reuseIdentifier:reuseIdentifier];
    
    if (self) {
        [self sdtCreateViews];
        
    }

    return self;

}


-(void)sdtCreateViews{

    //头像
    sdtUseImagerView = [[UIImageView alloc]initWithFrame:CGRectZero];
    sdtUseImagerView.layer.borderColor = [UIColor whiteColor].CGColor;
    sdtUseImagerView.layer.borderWidth = 1;
    [self addSubview:sdtUseImagerView];
    
    
    //微博内容
    sdtWeiboImageVeiw = [[UIImageView alloc]initWithFrame:CGRectZero];
    sdtWeiboImageVeiw.backgroundColor = [UIColor blackColor];
    [self addSubview:sdtWeiboImageVeiw];

    sdtTextLabel = [[UILabel alloc]initWithFrame:CGRectZero];\
    sdtTextLabel.font = [UIFont systemFontOfSize:12];
    //字体颜色
    sdtTextLabel.textColor = [UIColor whiteColor];
    //清除背景颜色
    sdtTextLabel.backgroundColor = [UIColor clearColor];
    sdtTextLabel.numberOfLines = 3;
    [self addSubview:sdtTextLabel];
    
    //添加点击手势
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapGesAction:)];
    
    [self addGestureRecognizer:tap];

}

-(void)tapGesAction:(UITapGestureRecognizer *)tap{
    //显示微博详情
}

-(void)layoutSubviews{
    [super layoutSubviews];
    
    MessageModel *message = (MessageModel *)self.annotation;
    
    //赋值 用户头像地址
    NSString *urlStr = message.model.user.profile_image_url;
    
    //将Str头像传递给UseImage
    [sdtUseImagerView sd_setImageWithURL:[NSURL URLWithString:urlStr]];
    
    //微博内容图片
    NSString *pic = message.model.thumbnail_pic;
    
    [sdtWeiboImageVeiw sd_setImageWithURL:[NSURL URLWithString:pic]];
    
    sdtTextLabel.text = message.model.text;
    
    //布局
    if (message.model.thumbnail_pic) {
        
        self.image = [UIImage imageNamed:@"nearby_map_photo_bg"];
        sdtTextLabel.hidden = YES;
        sdtWeiboImageVeiw.hidden = NO;
        
        //用户头像
        sdtUseImagerView.frame = CGRectMake(73,68, 30,30);
        sdtUseImagerView.frame = CGRectMake(15, 15, 90, 85);
    }else{
    
        self.image =[UIImage imageNamed:@"nearby_map_content"];
        sdtTextLabel.hidden = NO;
        sdtUseImagerView.hidden = YES;
        
        sdtUseImagerView.frame = CGRectMake(20, 20, 45, 45);
        
        sdtTextLabel.frame = CGRectMake(sdtUseImagerView.right+5, sdtUseImagerView.top+10, 110, 45);
    
    }
    
    
}


@end
