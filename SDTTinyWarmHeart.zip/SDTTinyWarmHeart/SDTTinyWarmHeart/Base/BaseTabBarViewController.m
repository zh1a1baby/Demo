//
//  BaseTabBarViewController.m
//  SDTTinyWarmHeart
//
//  Created by mac on 16/5/21.
//  Copyright © 2016年 mac. All rights reserved.
//

#import "BaseTabBarViewController.h"
#import "ThemeManager.h"



@interface BaseTabBarViewController (){
    
    ThemeImageView *_tabBarImage;
    ThemeImageView *_slideImage;
    


}

@end

@implementation BaseTabBarViewController

- (void)viewDidLoad {
    [super viewDidLoad];

   
    [self viscountSuViewConcontroller];
    
    

}

//视图将要布局的时候显示(移除标签栏的按钮加上新的按钮)
-(void)viewWillLayoutSubviews{
    [super viewWillLayoutSubviews];
    
    //移除标签栏的按钮
    [self removeItme];
    
    //新的标签栏的按钮
    [self tabBarImageButton];


}

//视图已经布局完成
-(void)viewDidLayoutSubviews{
    [super viewDidLayoutSubviews];
    
}

//获取TabBar的ViewController(子视图控制器)
-(void)viscountSuViewConcontroller{
    
    
    NSArray *storyBarr = @[@"Home",@"Message",@"Square",@"Profile",@"More",];
    
    NSMutableArray *mutableArr = [NSMutableArray arrayWithCapacity:storyBarr.count];
    
    for (int i = 0; i < storyBarr.count; i++) {
        //根据I取出数组中每一个StoryBoard中得名字
        NSString *storyBoardName = storyBarr[i];
        //根据StoryBoard的名字获取StoryBoard
        UIStoryboard *storyBoard = [UIStoryboard storyboardWithName:storyBoardName bundle:nil];
        //instantiateInitialViewController 获得当前StoryBoard的入口;
        UINavigationController *navigaC = [storyBoard instantiateInitialViewController];
        
        [mutableArr addObject:navigaC];
    }
    
    
    self.viewControllers = mutableArr;
    
    
    
}

//移除标签栏上得按钮
-(void)removeItme{

  
    for (UIView *view in self.tabBar.subviews) {
        
        
        
        //UITabBarButton获取私有的类方法
//        Class tabBarButton = NSClassFromString(@"UITabBarButton");
//        
//        
//        if ([view isKindOfClass:[tabBarButton class]]) {
//        
            //移除视图上的东西
            [view removeFromSuperview];
            
//        }
        
    }

}

#pragma mark --- 标签栏上得按钮
-(void)tabBarImageButton{
    
    
    _tabBarImage = [[ThemeImageView alloc]initWithFrame:CGRectMake(0, 0, KScreenWidth, KtabBarHeight)];
    
    //标签栏背景图片
    _tabBarImage.imageName = @"mask_navbar.png";
    
    //允许用户交互
    _tabBarImage.userInteractionEnabled = YES;
    
    //将图片添加到标签栏
    [self.tabBar addSubview:_tabBarImage];
    
    
    NSArray *imageArr = @[@"home_tab_icon_1",
                          @"home_tab_icon_2",
                          @"home_tab_icon_3",
                          @"home_tab_icon_4",
                          @"home_tab_icon_5"
                          ];
    
    CGFloat buttonWidth = KScreenWidth/imageArr.count;
    
    for (int i = 0; i<imageArr.count; i++) {

        //调用封装的类
        ThemeButton *button = [[ThemeButton alloc]initWithFrame:CGRectMake(i * buttonWidth, 0, buttonWidth, KtabBarHeight)];
        
        //获取数组中得图片
        NSString *string = imageArr[i];
        
        button.imageName = string;
        
        [button addTarget:self action:@selector(buttonAction:) forControlEvents:UIControlEventTouchUpInside];
        
        button.tag = 1000 + i;
        
        [_tabBarImage addSubview:button];
        
    }
    
    _slideImage = [[ThemeImageView alloc]initWithFrame:CGRectMake(0, 0,buttonWidth, 45)];
    
    _slideImage.imageName = @"home_bottom_tab_arrow.png";
    
    
    
    [_tabBarImage addSubview:_slideImage];
    
}

//Button点击事件
-(void)buttonAction:(UIButton *)button{

    
    NSInteger index = button.tag - 1000;
    
    //使用Tag值代理被点击视图的位置
    [self setSelectedIndex:index];

    
        [UIView animateWithDuration:0.35 animations:^{
        
        
        _slideImage.center = button.center;
           
            
//        [UIView commitAnimations]; 开始动画
        
    }];
    
    


    
    
    
}





@end
