//
//  BaseViewController.m
//  SDTTinyWarmHeart
//
//  Created by mac on 16/5/21.
//  Copyright © 2016年 mac. All rights reserved.
//

#import "BaseViewController.h"

@interface BaseViewController (){

    UIImage *image;
}

@end

@implementation BaseViewController
//移除通知
-(void)dealloc{
    
    [[NSNotificationCenter defaultCenter]removeObserver:self]; 


}


//coder(编码)adecoder(解码)
-(instancetype)initWithCoder:(NSCoder *)aDecoder{

    if(self = [super initWithCoder:aDecoder]){
    //接收通知
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(themechanged) name:KThemeChanged object:nil];
    }

    return self;
}


- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    [self themechanged];
    
    
}

#pragma mark --- 界面背景图
-(void)themechanged{
    
    //    UIImage *image = [UIImage imageNamed:@"bg_home.jpg"];


    image = [[ThemeManager sharedInstance] getImageWithImageName:@"bg_home.jpg"];
    
    CGImageRef cgImage = CGImageCreateWithImageInRect(image.CGImage, CGRectMake(0, 0, KScreenWidth, KScreenHeight));
    
    
    
    self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageWithCGImage:cgImage]];
    
    CGImageRelease(cgImage);
    



}

@end
