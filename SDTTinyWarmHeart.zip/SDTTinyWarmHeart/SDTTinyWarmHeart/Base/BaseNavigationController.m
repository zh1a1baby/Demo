//
//  BaseNavigationController.m
//  SDTTinyWarmHeart
//
//  Created by mac on 16/5/21.
//  Copyright © 2016年 mac. All rights reserved.
//

#import "BaseNavigationController.h"
#import "HomeViewController.h"
@interface BaseNavigationController ()

@end



@implementation BaseNavigationController

//移除通知
-(void)dealloc{

    [[NSNotificationCenter defaultCenter]removeObserver:self];

}

- (void)viewDidLoad {
    
    [super viewDidLoad];
 /*
    //    //设置导航栏背景图片
    [self.navigationBar setBackgroundImage:[UIImage imageNamed:@"222.jpg"] forBarMetrics:UIBarMetricsDefault];
    
    //    //修改导航栏字体
    //    //在plist中增加View并改为YES然后复写- (UIStatusBarStyle)preferredStatusBarStyle方法
    //修改导航栏样式
    self.navigationBar.barStyle = UIBarStyleBlack;
    
    //修改导航栏字体属性
    NSDictionary *dic = @{
                          
                          NSForegroundColorAttributeName:[UIColor blackColor],
                          NSFontAttributeName:[UIFont systemFontOfSize:25]
                          
                          };
    //将字典里面的属性赋给titlextAttributex;
    self.navigationBar.titleTextAttributes = dic;
    
    //将透明度设置为不透明
    self.navigationBar.translucent = NO;

   */
    
    
    
    
}



-(instancetype)initWithCoder:(NSCoder *)aDecoder{

    if (self = [super initWithCoder:aDecoder]) {
        
        //接收通知ThemeManager(封装的类中发来的通知接收)
        [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(themeDidChanged) name:KThemeChanged object:nil];
        
    }


    return self;

}

#pragma mark --- 导航栏背景图
-(void)themeDidChanged{
//    UIImage *image=[UIImage imageNamed:@"mask_titlebar.png"];
    
    
    
    
    UIImage *image = [[ThemeManager sharedInstance] getImageWithImageName:@"mask_titlebar.png"];
    
    
    CGImageRef cgImage=CGImageCreateWithImageInRect(image.CGImage, CGRectMake(0, 0, KScreenWidth, 64));
    
    //  设置导航拉背景图
    [self.navigationBar setBackgroundImage:[UIImage imageWithCGImage:cgImage] forBarMetrics:UIBarMetricsDefault];
    
    CGImageRelease(cgImage);
    
    UIColor *color = [[ThemeManager sharedInstance] getColorWithColorName:@"Mask_Title_color"];
    
    NSDictionary *dic = @{
                          
                          NSForegroundColorAttributeName:color,
                          NSFontAttributeName:[UIFont systemFontOfSize:19]
                          
                          };
    
    [self.navigationBar setTitleTextAttributes:dic];
    



}


@end
