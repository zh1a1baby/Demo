//
//  WXRefresh.h
//  PullRefresh
//
//  Created by Zheng on 15/10/14.
//  Copyright © 2015年 Qingwu Zheng. All rights reserved.
//

#ifndef WXRefresh_h
#define WXRefresh_h

#import "UIScrollView+PullDownRefresh.h"
#import "UIScrollView+PullUpRefresh.h"

#endif /* WXRefresh_h */
