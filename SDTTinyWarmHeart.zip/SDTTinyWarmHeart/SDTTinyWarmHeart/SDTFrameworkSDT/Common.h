//
//  Common.h
//  SDTTinyWarmHeart
//
//  Created by mac on 16/5/21.
//  Copyright © 2016年 mac. All rights reserved.
//

#ifndef Common_h
#define Common_h

#define kAppKey @"3210578965"
#define kRedirectURI @"https://api.weibo.com/oauth2/default.html"
#define kAppSecret @"c08e6a3dd1c80b6f1cbba62c96e7831e"


#define KScreenWidth [UIScreen mainScreen].bounds.size.width
#define KScreenHeight [UIScreen mainScreen].bounds.size.height

#define KtabBarHeight 49  //状态栏
#define kTabBarHeight 64 //导航栏
#define kThemeNameUserDefaults @"kThemeNameUserDefaults"

#define KThemeChanged @"KThemeChanged"

#define KAccess_token_ID @"KAccess_tokenID"

#define KWeiboTextFont 16    //正文字体大小
#define KRetweetedFontSize 15 //转发后字体的大小

#define kMainVCTranslationWidth 100//偏移X轴位置
#define kMainVCScale 0.8   //偏移量


#endif /* Common_h */
