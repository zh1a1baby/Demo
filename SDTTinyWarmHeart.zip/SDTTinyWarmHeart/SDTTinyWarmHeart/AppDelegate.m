//
//  AppDelegate.m
//  SDTTinyWarmHeart
//
//  Created by mac on 16/5/21.
//  Copyright © 2016年 mac. All rights reserved.
//

#import "AppDelegate.h"
#import "Common.h"
#import "WeiboSDK.h"
#import "BaseTabBarViewController.h"
#import "MenuViewController.h"
#import "LeftViewController.h"


@interface AppDelegate ()<WeiboSDKDelegate>

@end

@implementation AppDelegate

-(void)setBlock:(SuccessBlock)block{

    _block = block;

}


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    
//    [WeiboSDK enableDebugMode:YES];//打开调试信息
    [WeiboSDK registerApp:kAppKey];//向微博开放平台注册应用
    
    self.window = [[UIWindow alloc]initWithFrame:[UIScreen mainScreen].bounds];
    self.window.backgroundColor = [UIColor whiteColor];
    [self.window makeKeyAndVisible];
    
    //主视图控制器
    BaseTabBarViewController *tabBarVC = [[BaseTabBarViewController alloc]init];
    
    //侧滑视图
    LeftViewController *leftVC = [[LeftViewController alloc]init];
    
    
    MenuViewController *menuVC = [[MenuViewController alloc]initWithMainVC:tabBarVC withLeftVC:leftVC];
    
    self.window.rootViewController = menuVC;
    
    
    
    return YES;
}

//用户授权之后回调应用,直接想微博发送请求
-(BOOL)application:(UIApplication *)application openURL:(NSURL *)url sourceApplication:(NSString *)sourceApplication annotation:(id)annotation{


    
    return [WeiboSDK handleOpenURL:url delegate:self];
}

-(BOOL)application:(UIApplication *)application handleOpenURL:(NSURL *)url{


    return [WeiboSDK handleOpenURL:url delegate:self];
}

- (void)didReceiveWeiboRequest:(WBBaseRequest *)request{




}

- (void)didReceiveWeiboResponse:(WBBaseResponse *)response{
    
    
    //当微博登陆之后保存一下数据
    if ([response isKindOfClass:WBAuthorizeResponse.class]) {
        
        /*
         //    NSString *title = NSLocalizedString(@"认证结果", nil);
         NSString *message = [NSString stringWithFormat:@"%@: %d\nresponse.userId: %@\nresponse.accessToken: %@\n%@: %@\n%@: %@", NSLocalizedString(@"响应状态", nil), (int)response.statusCode,[(WBAuthorizeResponse *)response userID], [(WBAuthorizeResponse *)response accessToken],  NSLocalizedString(@"响应UserInfo数据", nil), response.userInfo, NSLocalizedString(@"原请求UserInfo数据", nil), response.requestUserInfo];
         UIAlertView *alert = [[UIAlertView alloc] initWithTitle:title
         message:message
         delegate:nil
         cancelButtonTitle:NSLocalizedString(@"确定", nil)
         otherButtonTitles:nil];
         
         self.wbtoken = [(WBAuthorizeResponse *)response accessToken];
         self.wbCurrentUserID = [(WBAuthorizeResponse *)response userID];
         self.wbRefreshToken = [(WBAuthorizeResponse *)response refreshToken];
         [alert show];
         */
        

        
        
        NSString *access_token = [(WBAuthorizeResponse *)response accessToken];
        
        _block(access_token);
        //获取access_token数据让那个本地持久化保存
        [[NSUserDefaults standardUserDefaults]setObject:access_token forKey:KAccess_token_ID];
        
        [[NSUserDefaults standardUserDefaults]synchronize];
        
        
        
        
    }
    
    
    



}


@end
