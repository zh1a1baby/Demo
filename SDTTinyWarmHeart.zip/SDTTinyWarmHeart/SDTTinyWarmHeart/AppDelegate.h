//
//  AppDelegate.h
//  SDTTinyWarmHeart
//
//  Created by mac on 16/5/21.
//  Copyright © 2016年 mac. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void (^ SuccessBlock)(NSString *access);
@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (nonatomic,copy)SuccessBlock block;

-(void)setBlock:(SuccessBlock)block;


@end

