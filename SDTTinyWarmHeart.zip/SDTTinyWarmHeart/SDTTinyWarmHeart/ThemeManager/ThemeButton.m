//
//  ThemeButton.m
//  SDTTinyWarmHeart
//
//  Created by mac on 16/5/23.
//  Copyright © 2016年 mac. All rights reserved.
//

#import "ThemeButton.h"

@implementation ThemeButton

//移除通知
-(void)dealloc{

    [[NSNotificationCenter defaultCenter]removeObserver:self];


}



-(instancetype)initWithFrame:(CGRect)frame{

    if (self = [super initWithFrame:frame]) {
        
        //创建Button的时候需要使用此方法才会接收到通知
        [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(themeDidButton) name:KThemeChanged object:nil];
        
    }

    return self;
}

-(void)themeDidButton{

    
    UIImage *image = [[ThemeManager sharedInstance] getImageWithImageName:_imageName];
    
    [self setImage:image forState:UIControlStateNormal];
    



}

-(void)setImageName:(NSString *)imageName{

    _imageName = imageName;
    
    [self themeDidButton];
   
}


@end
