//
//  ThemeLabel.m
//  SDTTinyWarmHeart
//
//  Created by mac on 16/5/23.
//  Copyright © 2016年 mac. All rights reserved.
//

#import "ThemeLabel.h"

@implementation ThemeLabel

-(void)dealloc{

    //移除通知
    [[NSNotificationCenter defaultCenter]removeObserver:self];


}



-(instancetype)initWithFrame:(CGRect)frame{

    if (self = [super initWithFrame:frame]) {
        
        //发送通知
        [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(themeColorChanged) name:KThemeChanged object:nil];
        
    }
    return self;

}

#pragma marl --- 如果是XIB写的就会调用此方法中得通知
-(void)awakeFromNib{

    //如果是在XIB中会调用此通知发送
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(themeColorChanged) name:KThemeChanged object:nil];


}


-(void)themeColorChanged{

    UIColor *color = [[ThemeManager sharedInstance]getColorWithColorName:_colorName];
    
    self.textColor = color;


}


-(void)setColorName:(NSString *)colorName{

    _colorName = colorName;
    
    [self themeColorChanged];



}


@end
