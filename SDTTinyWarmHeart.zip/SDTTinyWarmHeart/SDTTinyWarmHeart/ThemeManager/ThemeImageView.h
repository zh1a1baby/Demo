//
//  ThemeImageView.h
//  SDTTinyWarmHeart
//
//  Created by mac on 16/5/23.
//  Copyright © 2016年 mac. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ThemeImageView : UIImageView




//设置图片
@property(copy,nonatomic)NSString *imageName;

@property(assign,nonatomic)UIEdgeInsets edgeinsets;

@end
