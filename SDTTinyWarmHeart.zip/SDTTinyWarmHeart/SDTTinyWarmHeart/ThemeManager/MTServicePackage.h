//
//  MTServicePackage.h
//  PackagingService(封装)
//
//  Created by mac on 16/5/11.
//  Copyright © 2016年 mac. All rights reserved.
//

#import <Foundation/Foundation.h>
typedef void (^CompletionBlock) (id data);
@interface MTServicePackage : NSObject

//GET
+(void)GEtWithStringURL:(NSString *)url
                 params:(NSMutableDictionary *)params
            headrfields:(NSMutableDictionary *)hedrfields
        CompletionBlock:(CompletionBlock)completionBlock;

/*
 url:获取下载的地址或者数据
 params:设置请求体
 heatrfields:设置请求头
 bodyData:上传图片或者文件时,需要转换的Data
 CompletionBlock:完成时Block回调
 */
+(void)GEtWithStringURL:(NSString *)url
                 params:(NSMutableDictionary *)params
            headrfields:(NSMutableDictionary *)hedrfields
            accessToken:(NSString *)accessToken
        CompletionBlock:(CompletionBlock)completionBlock;

//POST
+(void)POSTWithStringURL:(NSString *)url
                 params:(NSMutableDictionary *)params
            headrfields:(NSMutableDictionary *)hedrfields
               bodyData:(NSData *)bodyData
        CompletionBlock:(CompletionBlock)completionBlock;


//GET/POST
+(void)requestWithStringURL:(NSString *)url
                 httpMethop:(NSString *)methop
                     params:(NSMutableDictionary *)parms
                headrfields:(NSMutableDictionary *)header
                   bodyData:(NSData *)bodyData
            CompletionBlock:(CompletionBlock)completionBlock;



@end
