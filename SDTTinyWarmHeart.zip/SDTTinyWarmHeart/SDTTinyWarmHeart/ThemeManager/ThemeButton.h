//
//  ThemeButton.h
//  SDTTinyWarmHeart
//
//  Created by mac on 16/5/23.
//  Copyright © 2016年 mac. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ThemeButton : UIButton


@property(copy,nonatomic)NSString *imageName;


@end
