//
//  ThemeLabel.h
//  SDTTinyWarmHeart
//
//  Created by mac on 16/5/23.
//  Copyright © 2016年 mac. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ThemeLabel : UILabel


@property(copy,nonatomic)NSString *colorName;

@end
