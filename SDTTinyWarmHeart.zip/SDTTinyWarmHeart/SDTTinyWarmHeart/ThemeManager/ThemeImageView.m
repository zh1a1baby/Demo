//
//  ThemeImageView.m
//  SDTTinyWarmHeart
//
//  Created by mac on 16/5/23.
//  Copyright © 2016年 mac. All rights reserved.
//

#import "ThemeImageView.h"

@implementation ThemeImageView

-(void)dealloc {
    
    
    //移除通知
    [[NSNotificationCenter defaultCenter]removeObserver:self];


}



-(void)awakeFromNib {
    //当图片是XIP得时候会调用此通知方法
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(themeDidchange) name:KThemeChanged object:nil];


}


//复写init方法接收通知
-(instancetype)initWithFrame:(CGRect)frame{


    if (self = [super initWithFrame:frame]) {
        
        //接收通知
        [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(themeDidchange) name:KThemeChanged object:nil];
        
        
    }

    return self;

}



-(void)setImageName:(NSString *)imageName{

    _imageName = imageName;
    
    
//    UIImage *image = [UIImage imageNamed:_imageName];
    
   
    [self themeDidchange];


}

-(void)themeDidchange{

    UIImage *image = [[ThemeManager sharedInstance] getImageWithImageName:_imageName];
    
    if (self.edgeinsets.top||self.edgeinsets.left||self.edgeinsets.bottom||self.edgeinsets.right) {
        
        image = [image resizableImageWithCapInsets:self.edgeinsets resizingMode:UIImageResizingModeTile];
        
    }
    
    
    self.image = image;
}
@end
