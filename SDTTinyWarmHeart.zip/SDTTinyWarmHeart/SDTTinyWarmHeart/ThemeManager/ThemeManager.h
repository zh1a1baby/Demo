//
//  ThemeManager.h
//  SDTTinyWarmHeart
//
//  Created by mac on 16/5/23.
//  Copyright © 2016年 mac. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
@interface ThemeManager : NSObject

//单例
+(instancetype)sharedInstance;

@property(copy,nonatomic)NSString *themeName;// 当前主题的名称
@property(strong,nonatomic)NSDictionary *themeDic;//接收theme.plist文件中得内容

//传入不同图片的名称,根据当前主题返回不同的图片
-(UIImage *)getImageWithImageName:(NSString *)imageName;


-(UIColor *)getColorWithColorName:(NSString *)colorName;
@end
