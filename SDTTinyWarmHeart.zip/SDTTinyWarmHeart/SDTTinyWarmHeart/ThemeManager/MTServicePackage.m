//
//  MTServicePackage.m
//  PackagingService(封装)
//
//  Created by mac on 16/5/11.
//  Copyright © 2016年 mac. All rights reserved.
//

#import "MTServicePackage.h"
#import "WeiboSDK.h"
#define Bundary @"--aGHJF653ds---"
@implementation MTServicePackage

//GET
+(void)GEtWithStringURL:(NSString *)url
                 params:(NSMutableDictionary *)params
            headrfields:(NSMutableDictionary *)hedrfields
        CompletionBlock:(CompletionBlock)completionBlock{
    
    if(!params){
        
        params = [NSMutableDictionary dictionary];
    }
    
    //数据持久化 当数据需要多次使用的时候定制一下
    NSString *access_token = [[NSUserDefaults standardUserDefaults]objectForKey:KAccess_token_ID];
    
    //容错处理
    if (access_token == nil) {
        
        WBAuthorizeRequest *request = [WBAuthorizeRequest request];
        request.redirectURI = kRedirectURI;
        request.scope = @"all";
        
        [WeiboSDK sendRequest:request];
        return;
    }
    [params setObject:access_token forKey:@"access_token"];
    


    
    //创建一个可变的字符串
    NSMutableString *fullStr = [NSMutableString string];
    
    //获取key和value
    for (NSString *key in params) {
        NSString *value = [params valueForKey:key];
        
        NSString *keyValue = [NSString stringWithFormat:@"%@=%@",key,value];
        
        [fullStr appendFormat:@"%@&",keyValue];
    }
    
    if (fullStr.length != 0) {
        
        [fullStr deleteCharactersInRange:NSMakeRange(fullStr.length - 1, 1)];
    }
    
    NSString *string = [NSString stringWithFormat:@"%@?%@",url,fullStr];
    
    //获取类方法的URL
    NSURL *fullurl = [NSURL URLWithString:string];
    //创建网络任务对象
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:fullurl cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:120];
    
    request.HTTPMethod = @"GET";
    //判断如果方法中有一个header就创建一个请求头
    if(hedrfields){
        //创建请求头
        [request setAllHTTPHeaderFields:hedrfields];
    }
    
    //容错处理
        //创建会话对象
    NSURLSession *session = [NSURLSession sharedSession];
    
    NSURLSessionDataTask *task = [session dataTaskWithRequest:request completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        //容错处理,当程序出错的使用执行这个方法
        if(error){
        
            NSLog(@"%@",error);
            return ;
        }
        
        //强转一下创建状态码实例对象
        NSHTTPURLResponse *httpresponse = (NSHTTPURLResponse *)response;
        //在程序运行成功的时候会有一个状态码(200为运行成功的状态 判断当程序运行成功等于200的时候创建一个多线程并且回调一下block)
        
        
        id jsonData = [NSJSONSerialization JSONObjectWithData:data
                                                      options:NSJSONReadingMutableContainers
                                                        error:nil];
        
        if(httpresponse.statusCode == 200){
        
        dispatch_sync(dispatch_get_main_queue(), ^{
           
            //回调block
            completionBlock(jsonData);
            
        });
        }
    }];
    
    //执行任务
    [task resume];


}

+(void)GEtWithStringURL:(NSString *)url
                 params:(NSMutableDictionary *)params
            headrfields:(NSMutableDictionary *)hedrfields
            accessToken:(NSString *)accessToken
        CompletionBlock:(CompletionBlock)completionBlock{

    if(!params){
        
        params = [NSMutableDictionary dictionary];
    }
    
    if(accessToken.length == 0){
    
        return;
    }
  
    [params setObject:accessToken forKey:@"access_token"];
    
    //创建一个可变的字符串
    NSMutableString *fullStr = [NSMutableString string];
    
    //获取key和value
    for (NSString *key in params) {
        NSString *value = [params valueForKey:key];
        
        NSString *keyValue = [NSString stringWithFormat:@"%@=%@",key,value];
        
        [fullStr appendFormat:@"%@&",keyValue];
    }
    
    if (fullStr.length != 0) {
        
        [fullStr deleteCharactersInRange:NSMakeRange(fullStr.length - 1, 1)];
    }
    
    NSString *string = [NSString stringWithFormat:@"%@?%@",url,fullStr];
    
    //获取类方法的URL
    NSURL *fullurl = [NSURL URLWithString:string];
    //创建网络任务对象
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:fullurl cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:120];
    
    request.HTTPMethod = @"GET";
    //判断如果方法中有一个header就创建一个请求头
    if(hedrfields){
        //创建请求头
        [request setAllHTTPHeaderFields:hedrfields];
    }
    
    //容错处理
    //创建会话对象
    NSURLSession *session = [NSURLSession sharedSession];
    
    NSURLSessionDataTask *task = [session dataTaskWithRequest:request completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        //容错处理,当程序出错的使用执行这个方法
        if(error){
            
            NSLog(@"%@",error);
            return ;
        }
        
        //强转一下创建状态码实例对象
        NSHTTPURLResponse *httpresponse = (NSHTTPURLResponse *)response;
        //在程序运行成功的时候会有一个状态码(200为运行成功的状态 判断当程序运行成功等于200的时候创建一个多线程并且回调一下block)
        
        
        id jsonData = [NSJSONSerialization JSONObjectWithData:data
                                                      options:NSJSONReadingMutableContainers
                                                        error:nil];
        
        if(httpresponse.statusCode == 200){
            
            dispatch_sync(dispatch_get_main_queue(), ^{
                
                //回调block
                completionBlock(jsonData);
                
            });
        }
    }];
    
    //执行任务
    [task resume];
    
}




//POST
+(void)POSTWithStringURL:(NSString *)url params:(NSMutableDictionary *)params headrfields:(NSMutableDictionary *)hedrfields bodyData:(NSData *)bodyData CompletionBlock:(CompletionBlock)completionBlock{
    //设置URL,获取数据
    NSURL *fullurl = [NSURL URLWithString:url];
    
    //创建任务对象
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:fullurl cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:120];
    //设置请求方式
    [request setHTTPMethod:@"POST"];
    //判断如果方法中有heder就创建一个请求头
    if (hedrfields) {
        [request setAllHTTPHeaderFields:hedrfields];
    }
    //容错处理(防止传入一个空得对象导致程序崩溃)
    if(!params){
    
       params = [NSMutableDictionary dictionary];
    
    }
    
    NSString *access_token=[[NSUserDefaults standardUserDefaults]objectForKey:KAccess_token_ID];
    //  容错处理
    if (access_token==nil) {
        return;
    }

    [params setObject:access_token forKey:@"access_token"];
    
    if(!bodyData){
    //请求体
    // params = [key,value,key,value......];
    //转化成字符串
    //key=value,key1=value1;
        //将key,value转化成字符串类型
        NSMutableString *boyStr = [NSMutableString string];
    
        for (NSString *ker in params) {
            
            id value = [params valueForKey:ker];
            
            NSString *keyForValue = [NSString stringWithFormat:@"%@=%@",ker,value];
            [boyStr appendFormat:@"%@&",keyForValue];
            
        }
        //去掉最后&
        if(boyStr.length != 0){
            [boyStr deleteCharactersInRange:NSMakeRange(boyStr.length - 1, 1)];
        }
        
        //转化成Data类型
        [request setHTTPBody:[boyStr dataUsingEncoding:NSUTF8StringEncoding]];
        
    }else{//复杂的数据
        
     //添加请求头
        NSString *headet = [NSString stringWithFormat:@"multipart/form-data; charset=utf-8;boundary=%@",Bundary];
        [request addValue:headet forHTTPHeaderField:@"Content-Type"];
       
        //获得请求体
        NSData *data = [self buildBodyDataWithParams:params bodyData:bodyData];
        
        [request setHTTPBody:data];
        
    }
    // 创建会话对象
    NSURLSession *session = [NSURLSession sharedSession];
    
    NSURLSessionDataTask *task = [session dataTaskWithRequest:request completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        
        if(error){
            
            NSLog(@"error = %@",error);
            
            //如果出错就直接返回
            return ;
        }
        //状态码
        NSHTTPURLResponse *httpurlResponse = (NSHTTPURLResponse *)response;
        
        
        
        id jsonData = [NSJSONSerialization JSONObjectWithData:data
                                                      options:NSJSONReadingMutableContainers
                                                        error:nil];
        //当程序运行成功的时候(状态码为200)
        if(httpurlResponse.statusCode == 200){
        //创建一个同步的多线程
        dispatch_sync(dispatch_get_main_queue(), ^{
            //回调block
            completionBlock(jsonData);
        });
        
        }
        
    }];
    [task resume];

}
//复杂的数据
+ (NSData *)buildBodyDataWithParams:(NSMutableDictionary *)params
                           bodyData:(NSData *)formData {
    
    //按照请求体的格式，拼接请求体
    //开头的bodyStr + 图片数据 + 结束str
    NSMutableData *bodyData = [NSMutableData data];
    
    //(1)bodyStr
    NSMutableString *bodyStr = [NSMutableString string];
    for (NSString *key in params) {
        id value = [params objectForKey:key];
        
        [bodyStr appendFormat:@"--%@\r\n", Bundary]; // \n 换行，\r 切换到行首
        [bodyStr appendFormat:@"Content-Disposition: form-data; name=\"%@\"", key];
        [bodyStr appendFormat:@"\r\n\r\n"];
        [bodyStr appendFormat:@"%@\r\n", value];
    }
    
    //.pic ---- 图片
    [bodyStr appendFormat:@"--%@\r\n", Bundary]; // \n 换行，\r 切换到行首
    [bodyStr
     appendFormat:
     @"Content-Disposition: form-data; name=\"pic\"; filename=\"file\""];
    [bodyStr appendFormat:@"\r\n"];
    [bodyStr appendFormat:@"Content-Type: application/octet-stream"];
    [bodyStr appendFormat:@"\r\n\r\n"];
    
    NSData *startData = [bodyStr dataUsingEncoding:NSUTF8StringEncoding];
    [bodyData appendData:startData];
    
    //(2)pic
    //图片数据添加
    [bodyData appendData:formData];
    
    //(3)--str--
    NSString *endStr = [NSString stringWithFormat:@"\r\n--%@--\r\n", Bundary];
    NSData *endData = [endStr dataUsingEncoding:NSUTF8StringEncoding];
    [bodyData appendData:endData];
    
    return bodyData;
}


+(void)requestWithStringURL:(NSString *)url httpMethop:(NSString *)methop params:(NSMutableDictionary *)parms headrfields:(NSMutableDictionary *)header bodyData:(NSData *)bodyData CompletionBlock:(CompletionBlock)completionBlock{
    
    //  GET
    if ([methop isEqualToString:@"GET"]) {
        
        [self GEtWithStringURL:url params:parms headrfields:header CompletionBlock:^(id data) {
            
            completionBlock(data);
        }];
        }else if ([methop isEqualToString:@"POST"]){//POST
        
            [self POSTWithStringURL:url params:parms headrfields:header bodyData:bodyData CompletionBlock:^(id data) {
                
                completionBlock(data);
            }];
            
           }

    

}
@end
