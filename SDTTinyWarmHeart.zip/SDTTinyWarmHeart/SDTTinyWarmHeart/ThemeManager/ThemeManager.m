//
//  ThemeManager.m
//  SDTTinyWarmHeart
//
//  Created by mac on 16/5/23.
//  Copyright © 2016年 mac. All rights reserved.
//

#import "ThemeManager.h"


@implementation ThemeManager

static ThemeManager *instance;


+(instancetype)sharedInstance{
   
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[self alloc]init];
        
    });
    
    
    return instance;

}

//复写init方法设置默认的主题
-(instancetype)init{

    if (self = [super init]) {
        //获取theme.plist
        NSString *path = [[NSBundle mainBundle]pathForResource:@"theme" ofType:@"plist"];
        //读取plist文件
        _themeDic = [NSDictionary dictionaryWithContentsOfFile:path];
        
        //设置默认主题
//        _themeName = @"猫爷";
        //通过NSUserDefaults(持久化数据)取值
    id myThemeName = [[NSUserDefaults standardUserDefaults]objectForKey:kThemeNameUserDefaults];

    if (myThemeName == nil) {
            
            //设置默认主题
            _themeName = @"猫爷";
        }else{
            _themeName = myThemeName;
        
        }
        
        
    }

    return self;

}

#pragma mark --- 标签栏图片
-(void)setThemeName:(NSString *)themeName{

    _themeName = themeName;
    //本地持久化,当换完皮肤之后保存切换的皮肤
    [[NSUserDefaults standardUserDefaults]setObject:themeName forKey:kThemeNameUserDefaults];
    
    [[NSUserDefaults standardUserDefaults]synchronize];
    
    //发送通知
    [[NSNotificationCenter defaultCenter]postNotificationName:KThemeChanged object:nil];

}

//拼接图片
-(UIImage *)getImageWithImageName:(NSString *)imageName{

    //bundle地址
    NSString *bundlePath = [[NSBundle mainBundle]resourcePath];
    
    
    //拼接plistz中的Key Value
    NSString *themePath = [_themeDic objectForKey:self.themeName];
    //Key/Value/图片内容
    NSString *fullPath = [themePath stringByAppendingFormat:@"/%@",imageName];
    
    NSString *latePath = [bundlePath stringByAppendingPathComponent:fullPath];

    //当图片需要多次使用的时候
//    UIImage *image = [UIImage imageNamed:fullPath];
    //当图片只需要使用一次的时候
    UIImage *image = [UIImage imageWithContentsOfFile:latePath];
    return image;
}

#pragma mark --- 字体的颜色
-(UIColor *)getColorWithColorName:(NSString *)colorName{


    //获取bundle地址
    NSString *bundlePath = [[NSBundle mainBundle]resourcePath];
    
    //凭借plist中得Key Value
    NSString *themePath = [_themeDic objectForKey:self.themeName];
    
    //获取KeyValue所对应的颜色
    NSString *fullColor = [bundlePath stringByAppendingFormat:@"/%@/config.plist",themePath];
    
    //取到config.plist字典中得东西
    NSDictionary *dic = [NSDictionary dictionaryWithContentsOfFile:fullColor];
    
    //取到小字典
    NSDictionary *colorDic = [dic objectForKey:colorName];
    
    //取到小字典中对应的RGB
    CGFloat red = [colorDic[@"R"] doubleValue];
    CGFloat green = [colorDic [@"G"]doubleValue];
    CGFloat blue = [colorDic [@"B"]doubleValue];
    
    //颜色的只 0~1
    CGFloat alpha = 1;
    
    //判断当alpha存在的时候就创建
    if(colorDic[@"alpha"]){
    
        alpha = [colorDic[@"alpha"] doubleValue];
    
    }
    
    
    UIColor *color = [UIColor colorWithRed:red/255.0 green:green/255.0 blue:blue/255.0 alpha:alpha];
    
    return color;
}

@end
