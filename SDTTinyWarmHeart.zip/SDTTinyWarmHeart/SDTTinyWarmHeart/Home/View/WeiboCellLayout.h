//
//  WeiboCellLayout.h
//  SDTTinyWarmHeart
//
//  Created by mac on 16/5/25.
//  Copyright © 2016年 mac. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "HomeModel.h"

@interface WeiboCellLayout : NSObject
@property(strong,nonatomic)HomeModel *model;

//整个单元格
@property(assign,nonatomic)CGRect frame;

//微博正文
@property(assign,nonatomic)CGRect textFrame;
//正文图片
@property(assign,nonatomic)CGRect picFrame;

//转发正文
@property(assign,nonatomic)CGRect retweedTextFrame;
//转发图片
@property(assign,nonatomic)CGRect retweedPicFrame;

//转发背景图片
@property(assign,nonatomic)CGRect retweedBgImageFrame;

//存放所有图片的数组
@property(nonatomic,strong)NSMutableArray *mutableImageFrames;

//多图部分的高度
@property(nonatomic,assign)CGFloat imageHeight;
@end
