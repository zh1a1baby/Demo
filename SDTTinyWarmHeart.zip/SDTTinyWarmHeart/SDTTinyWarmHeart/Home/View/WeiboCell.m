//
//  WeiboCell.m
//  SDTTinyWarmHeart
//
//  Created by mac on 16/5/25.
//  Copyright © 2016年 mac. All rights reserved.
//

#import "WeiboCell.h"
#import "UIImageView+WebCache.h"
#import "UIUtils.h"
#import "WXPhotoBrowser.h"

@interface WeiboCell ()<WXLabelDelegate,PhotoBrowerDelegate>

@end

@implementation WeiboCell

#pragma mark --- 懒加载循环获取九宫格图片
-(NSMutableArray *)mutableImageArr{
    //当图片不存在的时候
    if(!_mutableImageArr){
        //创建可变的图片数组对象
        _mutableImageArr = [NSMutableArray array];
        for (int i = 0; i < 9; i++) {
            //循环创建图片 , 不给坐标
            UIImageView *imageV = [[UIImageView alloc]initWithFrame:CGRectZero];
            //填充模式
            imageV.contentMode = UIViewContentModeScaleAspectFill;
            //裁剪
            imageV.clipsToBounds = YES;
            //打开用户交互
            imageV.userInteractionEnabled = YES;
            
            imageV.tag = 9000+i;
            
            //添加手势
            UITapGestureRecognizer *tapGR = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapGRAction:)];
            
            [imageV addGestureRecognizer:tapGR];
            [self.contentView addSubview:imageV];
            [_mutableImageArr addObject:imageV];
            
        }
    }

    return _mutableImageArr;
}

#pragma mark --- 微博首页点击图片放大手势
-(void)tapGRAction:(UITapGestureRecognizer *)tapGR{

    //通过Tag值来辨认点击的哪一张图片
    NSInteger idenx = tapGR.view.tag - 9000;

    //self.window要弹过去的视图   idenx是第几张图片
    [WXPhotoBrowser showImageInView:self.window selectImageIndex:idenx delegate:self];
    


}
//需要显示的图片个数
- (NSUInteger)numberOfPhotosInPhotoBrowser:(WXPhotoBrowser *)photoBrowser{

    //当图片存在的时候
    if(_layout.model.pic_urls.count){
        //返回正文图片
        return _layout.model.pic_urls.count;
        
        //当转发的图片存在的时候
    }else if(_layout.model.retweeted_status.pic_urls.count){
    
    
        return _layout.model.retweeted_status.pic_urls.count;
    
    }
    return 0;
    
}

//返回需要显示的图片对应的Photo实例,通过Photo类指定大图的URL,以及原始的图片视图
- (WXPhoto *)photoBrowser:(WXPhotoBrowser *)photoBrowser
             photoAtIndex:(NSUInteger)index{

    WXPhoto *photo = [[WXPhoto alloc]init];
    //获得原始的图片ImageView
    UIImageView *imageV = [self.mutableImageArr objectAtIndex:index];
    
    photo.srcImageView = imageV;
    
    //小图的URLString
    NSArray *urlsArr = nil;
    if (_layout.model.pic_urls.count) {
        
        urlsArr = _layout.model.pic_urls;
    }else if(_layout.model.retweeted_status.pic_urls.count){
    
        urlsArr = _layout.model.retweeted_status.pic_urls;
    
    }
    
    //将图片放到字典当中
    NSDictionary *dic = [urlsArr objectAtIndex:index];
    //取到字典中得图片
    NSString *urlsStr = [dic objectForKey:@"thumbnail_pic"];
    
    //当点击的时候弹到另一个页面的图片放大
    urlsStr = [urlsStr stringByReplacingOccurrencesOfString:@"thumbnail" withString:@"large"];
    
    //大图的URL
    photo.url = [NSURL URLWithString:urlsStr];
    
    return photo;
}



#pragma mark --- 微博正文
- (void)awakeFromNib {
    
    //微博正文
    self.weiboTextLabel =[[WXLabel alloc]initWithFrame:CGRectZero];
    //正文字体大小
    self.weiboTextLabel.font = [UIFont systemFontOfSize:KWeiboTextFont];
    self.weiboTextLabel.numberOfLines = 0;
    self.weiboTextLabel.wxLabelDelegate = self;
    
    
    [self.contentView addSubview:self.weiboTextLabel];
    
    
    self.nickNameLabel.colorName=@"Timeline_Notice_color";//头像
    self.timeLabel.colorName=@"Timeline_Time_color";//时间
    self.sourceLabel.colorName=@"Timeline_Time_color";//来源
    
}


#pragma mark --- 微博数据的实现
-(void)setModel:(HomeModel *)model {


    _model =model;
    
    //昵称
    self.nickNameLabel.text = _model.user.screen_name;
    //头像
    NSURL *url = [NSURL URLWithString:_model.user.profile_image_url];
    
    [self.headerImageView sd_setImageWithURL:url];
    
    //将头像设置圆角
    self.headerImageView.layer.cornerRadius = 25;
    
    //是否裁剪多余图片
    self.headerImageView.layer.masksToBounds = YES;
    
    //时间
    self.timeLabel.text = [UIUtils dataTimeAgoWithDataString:_model.created_at];
    
    //来源
    self.sourceLabel.text = [UIUtils sourceTextWithString:_model.source];
    
    
    //微博正文
    self.weiboTextLabel.text = [UIUtils faceStringWithWeiboText:_model.text];
    
    //微博图片thumbnail_pic缩略图地址
    if(_model.thumbnail_pic){
    
//    
//        NSURL *picURL = [NSURL URLWithString:_model.thumbnail_pic];
//        
//        [self.picImageView sd_setImageWithURL:picURL];
        
        //给ImageView 设置图片
        [self shouIamgeViewWillUrls:_model.pic_urls];
    }
    
    if (_model.retweeted_status) {
        
        //转发微博正文
        self.retweedTextLabel.text = [UIUtils faceStringWithWeiboText:_model.retweeted_status.text];
        
        //转发微博图片
        if (_model.retweeted_status.thumbnail_pic) {
//            
//            NSURL *picRetweetedURL = [NSURL URLWithString:_model.retweeted_status.thumbnail_pic];
//            [self.retweedPicView sd_setImageWithURL:picRetweetedURL];
            [self shouIamgeViewWillUrls:_model.retweeted_status.pic_urls];

            
        }
    }
    
    
}

#pragma mark --- 微博九宫图方法
-(void)shouIamgeViewWillUrls:(NSArray *)urls{

    //Urls循环出来的图片个数(9)
    for (int i = 0; i<urls.count; i++) {
        
        //获取循环图片的单张图片
        UIImageView *imageView = [self.mutableImageArr objectAtIndex:i];
        
        //取到urls中存储的图片
        NSDictionary *dic = urls[i];
        
        //取到字典中得图片
        NSString *str = dic[@"thumbnail_pic"];
        
        //将取到的图片传递给ImageView显示;
        [imageView sd_setImageWithURL:[NSURL URLWithString:str]];
    }



}

#pragma mark --- 微博正文与转发的赋值
-(void)setLayout:(WeiboCellLayout *)layout{
    
    _layout= layout;
    
    //正文
    self.weiboTextLabel.frame = _layout.textFrame;
    
    //正文图片
//    self.picImageView.frame = _layout.picFrame;
    
    for (int i = 0; i < 9 ; i++) {
        
        //取到第一张图片
        UIImageView *imageView = [self.mutableImageArr objectAtIndex:i];
        //取到第一张图片的坐标
        CGRect frame = [[layout.mutableImageFrames objectAtIndex:i] CGRectValue];
        
        imageView.frame = frame;
    }
    
    //转发微博正文背景图片
    self.retweedBgImageView.frame = _layout.retweedBgImageFrame;
    
    //转发正文
    self.retweedTextLabel.frame = _layout.retweedTextFrame;
    
    //转发图片
    self.retweedPicView.frame = _layout.retweedPicFrame;
    
    
    
    
}



#pragma mark --- 懒加载
@synthesize picImageView = _picImageView;
@synthesize retweedTextLabel = _retweedTextLabel;
@synthesize retweedPicView = _retweedPicView;
@synthesize retweedBgImageView = _retweedBgImageView;

//正文图片
-(UIImageView *)picImageView{

    if (_picImageView == nil) {
        
        _picImageView = [[UIImageView alloc]initWithFrame:CGRectZero];
        
        [self.contentView addSubview:_picImageView];
        
        
    }

    return _picImageView;
}

//转发的正文内容
-(WXLabel *)retweedTextLabel{
    if (_retweedTextLabel == nil) {
        
        _retweedTextLabel = [[WXLabel alloc]initWithFrame:CGRectZero];
        _retweedTextLabel.font = [UIFont systemFontOfSize:KRetweetedFontSize];
        _retweedTextLabel.numberOfLines = 0;
        
        //WXLabel代理方法
        _retweedTextLabel.wxLabelDelegate = self;
        
        [self.contentView addSubview:self.retweedTextLabel];
        
    }


    return _retweedTextLabel;

}

//转发图片
-(UIImageView *)retweedPicView {

    if (_retweedPicView ==nil) {
        
        _retweedPicView = [[UIImageView alloc]initWithFrame:CGRectZero];
        [self.contentView addSubview:self.retweedPicView];
    }

    return _retweedPicView;

}

//转发内容的背景
-(ThemeImageView *)retweedBgImageView {

    if (_retweedBgImageView == nil) {
        
        
        _retweedBgImageView = [[ThemeImageView alloc]initWithFrame:CGRectZero];
        //转发微博背景
        _retweedBgImageView.edgeinsets = UIEdgeInsetsMake(10, 30, 10, 10);
        _retweedBgImageView.imageName =@"timeline_rt_border_9.png";
        [self.contentView insertSubview:_retweedBgImageView atIndex:0];
        
    }
    return _retweedBgImageView;

}
#pragma mark ---WXLabel代理方法


//检测文本存在超链接的正则表达式
-(NSString *)contentsOfRegexStringWithWXLabel:(WXLabel *)wxLabel{

    NSString *regex = @"http://([a-z0-9A-Z._-]+(/)?)+";
    NSString *regex1 = @"@[\\w._-]{2,30}";
    NSString *regex2 = @"#[^#]+#";
    
    NSString *regeFullStr = [NSString stringWithFormat:@"%@|%@|%@",regex,regex1,regex2];

    return regeFullStr;

}

//超链接颜色的方法
-(UIColor *)linkColorWithWXLabel:(WXLabel *)wxLabel{
    
    UIColor *color=[[ThemeManager sharedInstance]getColorWithColorName:@"Link_color"];
    
    return color;
}

-(void)toucheEndWXLabel:(WXLabel *)wxLabel withContext:(NSString *)context{



    NSLog(@"%@",context);


}

@end
