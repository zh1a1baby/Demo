//
//  WeiboView.h
//  SDTTinyWarmHeart
//
//  Created by mac on 16/5/25.
//  Copyright © 2016年 mac. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WeiboView : UITableView

//接收微博正文呢中得内容
@property(strong,nonatomic)NSArray *dataList;


@end
