//
//  WeiboView.m
//  SDTTinyWarmHeart
//
//  Created by mac on 16/5/25.
//  Copyright © 2016年 mac. All rights reserved.
//

#import "WeiboView.h"
#import "WeiboCell.h"
#import "WeiboCellLayout.h"

static NSString *identifer = @"weibo_cell";
@interface WeiboView ()<UITableViewDataSource,UITableViewDelegate>

@end


@implementation WeiboView


-(instancetype)initWithCoder:(NSCoder *)aDecoder{

    if (self = [super initWithCoder:aDecoder]) {
        
        
        [self tableVC];
        
    }



    return self;

}

-(void)tableVC{

    self.delegate = self;
    self.dataSource = self;
    self.backgroundColor =[UIColor clearColor];
    
    //注册代理
    [self registerNib:[UINib nibWithNibName:@"WeiboCell" bundle:[NSBundle mainBundle]] forCellReuseIdentifier:identifer];

}

#pragma mark ---代理方法
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{


    return _dataList.count;

}



- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{

    WeiboCell *cell = [tableView dequeueReusableCellWithIdentifier:identifer forIndexPath:indexPath];

    WeiboCellLayout *layout =_dataList[indexPath.row];
    
    cell.model = layout.model;
    cell.layout = layout;
    

    cell.backgroundColor = [UIColor clearColor];
    return cell;

}

//单元格高度
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{


    WeiboCellLayout *layout = _dataList[indexPath.row];
    
    //根据微博正文的内容改变单元格的高度
    return layout.frame.size.height;



}


@end
