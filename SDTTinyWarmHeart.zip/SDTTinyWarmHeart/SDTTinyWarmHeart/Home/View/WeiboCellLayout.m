//
//  WeiboCellLayout.m
//  SDTTinyWarmHeart
//
//  Created by mac on 16/5/25.
//  Copyright © 2016年 mac. All rights reserved.
//

#import "WeiboCellLayout.h"
#import "WXLabel.h"
#define KTopCellHeight 60

#define KLineSpace 10 //九格图片上下间距
#define KItemGap 5 //九格图左右间距


@implementation WeiboCellLayout

-(NSMutableArray *)mutableImageFrames{

    if (!_mutableImageFrames) {
        
        _mutableImageFrames = [NSMutableArray array];
    }

    return _mutableImageFrames;

}


-(void)setModel:(HomeModel *)model{

    _model = model;
    
    [self _layoutSubViewFrame];
}


#pragma mark --- 计算微博正文内容图片以及转发内容和图片的坐标
-(void)_layoutSubViewFrame{

    //  微博正文
    CGFloat textWidth=KScreenWidth - 10;
    /**
     NSStringDrawingUsesLineFragmentOrigin 会自动换行
     
     NSStringDrawingUsesFontLeading 会加上行间距
     
     NSStringDrawingUsesDeviceMetrics 使用设备字体（默认使用印刷字体）
     
     NSStringDrawingTruncatesLastVisibleLine（不能单独使用，需要配合换行使用）
     如果最后一行显示不开，会自动变为省略号
     */
    /*
    NSDictionary *att=@{
                        NSFontAttributeName:[UIFont systemFontOfSize:KWeiboTextFont],
                        NSForegroundColorAttributeName:[UIColor blackColor]
                        };
    
    CGRect textRect = [_model.text boundingRectWithSize:CGSizeMake(textWidth, 2000) options:NSStringDrawingUsesLineFragmentOrigin attributes:att context:nil];
     CGFloat textHeight = CGRectGetHeight(textRect);
     
    */
    
    CGFloat textHeight = [WXLabel getTextHeight:KWeiboTextFont width:textWidth text:_model.text linespace:10];
    
    self.textFrame=CGRectMake(5, KTopCellHeight, textWidth, textHeight);
    
//    
//    CGFloat picX=CGRectGetMinX(self.textFrame);
//    CGFloat picY=CGRectGetMaxY(self.textFrame) + 5;
//    
//    CGFloat picWidth=0;
//    CGFloat picHeight=0;
    
    //  正文图片
//    if (_model.thumbnail_pic) {
    
//        picWidth=100;
//        picHeight=100;
//        
//        self.picFrame=CGRectMake(picX, picY, picWidth, picHeight);
    
        CGFloat x = CGRectGetMinX(self.textFrame);
        CGFloat y = CGRectGetMaxY(self.textFrame)+KLineSpace;
        
        //每个图片的尺寸
        CGFloat itemSize = (CGRectGetWidth(self.textFrame)-2*KItemGap)/3;
        
        
        NSInteger row = 0;//行
        NSInteger column = 0;//列
        
        // 获取每一张图片加到视图上显示
        for (int i =0; i <_model.pic_urls.count; i++) {
            
            row = i/3;
            column = i%3;
            
            //每一张图片的大小与间距
            CGRect frame = CGRectMake(x+column*(itemSize+KItemGap), y+row*(itemSize +KItemGap), itemSize, itemSize);
            
            //将所有有的数据添加到mutableImageFrames
            [self.mutableImageFrames addObject:[NSValue valueWithCGRect:frame]];
            
        }
        
    
        /*
         行数  0~3
         图片之间的间隙 0~2
         正文和图片之间的间隙 0~1
         */
        
        
        //count=1+2/3 = 1....2+2/3 =1...4+2/3 = 2  7+2/3 =3......
        NSInteger line = (_model.pic_urls.count +2)/3;

        //1*图片大小+MAX
        _imageHeight = line*itemSize+MAX(0, (line - 1))*KItemGap+MIN(1, MAX(0, line))*KLineSpace;
        
   // }
    
    //  转发微博
    if (_model.retweeted_status) {
        
        //    转发微博的背景图
        CGFloat retweededBgX=CGRectGetMinX(self.textFrame);
        CGFloat retweededBgY=CGRectGetMaxY(self.textFrame) + 5;
        
        CGFloat retweededWidth=KScreenWidth-10;
        
        self.retweedBgImageFrame=CGRectMake(retweededBgX, retweededBgY, retweededWidth, 0);
        
        //    正文
        CGFloat retweetedTextWidth=CGRectGetWidth(self.retweedBgImageFrame)-10;
        
        /*
        NSDictionary *retweetedAtt=@{
                                     NSFontAttributeName:[UIFont systemFontOfSize:KRetweetedFontSize],
                                     NSForegroundColorAttributeName:[UIColor blackColor]
                                     };
        
        
        CGRect retweetedTextRect = [_model.retweeted_status.text boundingRectWithSize:CGSizeMake(retweetedTextWidth, 2000) options:NSStringDrawingUsesLineFragmentOrigin attributes:retweetedAtt context:nil];
         */
        
        
        
        CGFloat retweetedTextHeight = [WXLabel getTextHeight:KRetweetedFontSize width:retweetedTextWidth text:_model.retweeted_status.text linespace:10];
        
        CGFloat retweetedTextX=CGRectGetMinX(self.retweedBgImageFrame)+5;
        
        CGFloat retweetedTextY=CGRectGetMinY(self.retweedBgImageFrame)+10;
        
        self.retweedTextFrame=CGRectMake(retweetedTextX, retweetedTextY, retweetedTextWidth, retweetedTextHeight);
        /*
        //    转发微博正文图片
        
//        CGFloat retweetedPicWidth=0;
//        CGFloat retweetedPicHeight=0;
//        
//        if (_model.retweeted_status.thumbnail_pic) {
//            
//            retweetedPicWidth=100;
//            retweetedPicHeight=100;
//            
//            CGFloat retweetedPicX=CGRectGetMinX(self.retweedBgImageFrame)+5;
//            CGFloat retweetedPicY=CGRectGetMaxY(self.retweedTextFrame)+10;
//            
//            
//            self.retweedPicFrame=CGRectMake(retweetedPicX, retweetedPicY, retweetedPicWidth, retweetedPicHeight);
//            
//        }
        */
        CGFloat x = CGRectGetMinX(self.retweedTextFrame);
        CGFloat y = CGRectGetMaxY(self.retweedTextFrame)+KLineSpace;
        
        //每个图片的尺寸
        CGFloat itemSize = (CGRectGetWidth(self.retweedTextFrame)-2*KItemGap)/3;
        
        
        NSInteger row = 0;//行
        NSInteger column = 0;//列
        
        // 获取每一张图片加到视图上显示
        for (int i =0; i <_model.retweeted_status.pic_urls.count; i++) {
            
            row = i/3;
            column = i%3;
            
            //每一张图片的大小与间距
            CGRect frame = CGRectMake(x+column*(itemSize+KItemGap), y+row*(itemSize +KItemGap), itemSize, itemSize);
            
            //将所有有的数据添加到mutableImageFrames
            [self.mutableImageFrames addObject:[NSValue valueWithCGRect:frame]];
            
        }
        
        /*
         行数  0~3
         图片之间的间隙 0~2
         正文和图片之间的间隙 0~1
         */
    
        //count=1+2/3 = 1....2+2/3 =1...4+2/3 = 2  7+2/3 =3......
        NSInteger line = (_model.retweeted_status.pic_urls.count +2)/3;
        
        //1*图片大小+MAX
        _imageHeight = line*itemSize+MAX(0, (line - 1))*KItemGap+MIN(1, MAX(0, line))*KLineSpace;

        
        
        //    给转发背景图设置高度
        CGFloat retweetedBgHeight=5+CGRectGetHeight(self.retweedTextFrame)+10+_imageHeight+15;
        
        CGRect retweetedNewFrame=self.retweedBgImageFrame;
        
        retweetedNewFrame.size.height=retweetedBgHeight;
        
        self.retweedBgImageFrame=retweetedNewFrame;
        
        
        
    }
    
    CGFloat cellHeight=0;
    
    if (_model.thumbnail_pic) {
        
        cellHeight=5+CGRectGetHeight(self.textFrame)+_imageHeight+5+KTopCellHeight+40;
        
    }else if(_model.retweeted_status){
        
        
        cellHeight=5+CGRectGetHeight(self.retweedBgImageFrame)+10+CGRectGetHeight(self.textFrame)+5+KTopCellHeight+10;

    }else{
    
              cellHeight =CGRectGetHeight(self.textFrame)+KTopCellHeight+40;

    }
    
    self.frame=CGRectMake(0, 0, KScreenWidth, cellHeight);
    
    
    //i上上面的饿for循环下来是第几张图片pic_urls就代表几 补全没有数据的ImageView的frame
    for (NSInteger i = _model.retweeted_status.pic_urls.count; i<9; i++) {
        
        [self.mutableImageFrames addObject:[NSValue valueWithCGRect:CGRectZero]];
        
    }



}

@end
