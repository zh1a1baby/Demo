//
//  WeiboCell.h
//  SDTTinyWarmHeart
//
//  Created by mac on 16/5/25.
//  Copyright © 2016年 mac. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HomeModel.h"
#import "WeiboCellLayout.h"
#import "WXLabel.h"
@interface WeiboCell : UITableViewCell

@property(strong,nonatomic)HomeModel *model;
@property(strong,nonatomic)WeiboCellLayout *layout;

//微博正文
@property(strong,nonatomic)WXLabel *weiboTextLabel;

//正文图片
@property(strong,nonatomic,readonly)UIImageView *picImageView;

//转发正文
@property(strong,nonatomic,readonly)WXLabel *retweedTextLabel;
//转发图片
@property(strong,nonatomic,readonly)UIImageView *retweedPicView;

//转发微博正文图片
@property(strong,nonatomic,readonly)ThemeImageView *retweedBgImageView;

@property(nonatomic,strong)NSMutableArray *mutableImageArr;




@property (weak, nonatomic) IBOutlet UIImageView *headerImageView;//头像
@property (weak, nonatomic) IBOutlet ThemeLabel *nickNameLabel;//昵称
@property (weak, nonatomic) IBOutlet ThemeLabel *timeLabel;//时间
@property (weak, nonatomic) IBOutlet ThemeLabel *sourceLabel;//来源








@end
