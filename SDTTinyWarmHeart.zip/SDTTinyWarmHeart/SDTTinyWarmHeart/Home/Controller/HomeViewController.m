//
//  HomeViewController.m
//  SDTTinyWarmHeart
//
//  Created by mac on 16/5/22.
//  Copyright © 2016年 mac. All rights reserved.
//

#import "HomeViewController.h"
#import "MTServicePackage.h"
#import "HomeModel.h"
#import "UserModel.h"
#import "WeiboView.h"
#import "WeiboSDK.h"
#import "AppDelegate.h"
#import "MenuViewController.h"
#import <AVFoundation/AVFoundation.h>

#import "WXRefresh.h"
#import "WeiboCellLayout.h"
@interface HomeViewController (){

    NSNumber *_since_id;
    SystemSoundID sounID;//播放音频

}
@property (weak, nonatomic) IBOutlet WeiboView *weiboTableView;

//存储的数据
@property (strong,nonatomic)NSMutableArray *dataList;

@property(strong,nonatomic)ThemeImageView *notifyIamgeView;
@end

@implementation HomeViewController
//当需要多次使用的时候就使用懒加载
-(ThemeImageView *)notifyIamgeView{
    if (!_notifyIamgeView) {
        
        //每次刷新的时候
        _notifyIamgeView = [[ThemeImageView alloc]initWithFrame:CGRectMake(0, -40, KScreenWidth, 40)];
        _notifyIamgeView.imageName = @"timeline_notify";
        
        //每次刷新的条数
        ThemeLabel *notifiLabel = [[ThemeLabel alloc]initWithFrame:_notifyIamgeView.bounds];
        notifiLabel.tag = 10001;
        //文字居中
        notifiLabel.textAlignment = NSTextAlignmentCenter;
        //颜色
        notifiLabel.colorName = @"Link_color";
        
        [_notifyIamgeView addSubview:notifiLabel];
        [self.view addSubview:_notifyIamgeView];
        
    }
    
    return _notifyIamgeView;
}




- (void)viewDidLoad {
    [super viewDidLoad];
    
    AppDelegate *delegat = (AppDelegate *)[UIApplication sharedApplication].delegate;
    
    [delegat setBlock:^(NSString *access) {
        
        [self firstLoadNewData:access];
    }];
    
    
   
    self.automaticallyAdjustsScrollViewInsets = NO;
    
    
    //下拉刷新
    //弱引用解除相互持有
    __weak HomeViewController *weakSelf = self;
    
    [self.weiboTableView addPullDownRefreshBlock:^{
     
        //保证对象不会被释放
        __strong HomeViewController *strongSelf = weakSelf;
        
        //当下拉刷新的时候刷新数据(刷新的时候会相互持有一下 , 需要创建一个弱引用.)
        [strongSelf loadNewData];
        
    }];
    
    //上拉刷新加载数据
//    __weak HomeViewController *weakSelf1 = self;
    
    [self.weiboTableView addInfiniteScrollingWithActionHandler:^{
        
        //保证对象不会被释放
        __strong HomeViewController *strongSelf1 = weakSelf;
        
        //当下拉刷新的时候刷新数据(刷新的时候会相互持有一下 , 需要创建一个弱引用.)
        [strongSelf1 loadDownData];
    
    }];


    
    
    
}

-(void)viewWillAppear:(BOOL)animated{

    [super viewWillAppear:animated];
    
    NSString *accessToken = [[NSUserDefaults standardUserDefaults]objectForKey:KAccess_token_ID];
    
    if (accessToken.length == 0) {
        
        [self loginAction:nil];
    }else{
    
        [self loadNewData];
    }

    
    MenuViewController *menVC = (MenuViewController *) [UIApplication sharedApplication].keyWindow.rootViewController;
    
    menVC.pan.enabled = YES;




}

//当首页视图消失了得时候取消侧滑
-(void)viewWillDisappear:(BOOL)animated{

    MenuViewController *menVC = (MenuViewController *) [UIApplication sharedApplication].keyWindow.rootViewController;
    
    menVC.pan.enabled = NO;
    




}


#pragma mark--- 登陆
- (IBAction)loginAction:(id)sender {
    
    
    WBAuthorizeRequest *request = [WBAuthorizeRequest request];
    request.redirectURI = kRedirectURI;
    request.scope = @"all";
    [WeiboSDK sendRequest:request];
    

    
}

#pragma mark --- 侧滑
- (IBAction)refreshAction:(id)sender {
    
    MenuViewController *menuVC = (MenuViewController *)self.view.window.rootViewController;
    
    if (menuVC.isOpen) {
        //如果视图已经侧滑 则不在侧滑
        [menuVC closeMainVC];
        
    }else{
    
        //如果视图没有侧滑则会进行侧滑
        [menuVC openMainVC];
    
    
    }
    
    
    
    
}

-(void)firstLoadNewData:(NSString *)accessToken{
    
    NSMutableDictionary *params = [NSMutableDictionary
                                   dictionaryWithDictionary:@{@"count": @5
                                                              }];
    
    
    [MTServicePackage GEtWithStringURL:@"https://api.weibo.com/2/statuses/home_timeline.json" params:params headrfields:nil accessToken:accessToken CompletionBlock:^(id data) {
        [self loadFinishNewData:data];
        
    }];
    
}

#pragma mark --- 下拉加载新数据
-(void)loadNewData{

    //取ID
   _since_id = @0;
    
    if (self.dataList.count != 0) {
        
        //当dataList中有数据(不等于0的时候)的时候就通过下标去找到他的第一个数据
        WeiboCellLayout *layout = self.dataList[0];
        
        //取到model中得ID;
        _since_id = layout.model.weiboID;
        
        
    }
    NSMutableDictionary *params = [NSMutableDictionary
                                dictionaryWithDictionary:@{@"count": @5,@"since_id":[NSString stringWithFormat:@"%@",_since_id]}];

    
    [MTServicePackage GEtWithStringURL:@"https://api.weibo.com/2/statuses/home_timeline.json" params:params headrfields:nil CompletionBlock:^(id data){
    
        //获得新的数据
        [self loadFinishNewData:data];
    }];
    
    
    
}

//下拉刷新数据的方法
-(void)loadFinishNewData:(id)data{

    //创建可变的数组(一会存储Model中得获取的内容)
//    NSMutableArray *dataList = [NSMutableArray array];
    
        //获得数组中的所有数据
    NSArray *array = [data objectForKey:@"statuses"];
    
        //创建一个存储新数据的可变数组
    NSMutableArray *mutableArr = [NSMutableArray array];
    
    NSMutableArray *visibleArr = [NSMutableArray array];
        
        
        //遍历数组中得数据
        for (NSDictionary *source in array) {
            
            //获得source微博正文内容
            HomeModel *model = [[HomeModel alloc]initWithDataDic:source];
            
            WeiboCellLayout *layout = [[WeiboCellLayout alloc]init];
            
            //layout获取网络中存储在model中得数据传递给weiboView中得cell
            layout.model = model;
            
            //如果不是第一次进入程序的时候
            if (![_since_id intValue]==0) {
                
                //如果没有数据就添加
                [visibleArr addObject:@"0"];
            }
            
            //dataList中储存的新数据
            [mutableArr addObject:layout];
            
        }
    
  
        
        //获得最新数据中得第一个数据并且将新获得的数据按顺序从上往下排列
    [mutableArr addObjectsFromArray:self.dataList];
    
    self.dataList = mutableArr;
    
        //获取source的内容,并传递
    _weiboTableView.dataList = self.dataList;
        
    [_weiboTableView reloadData];
    

    //停止刷新数据
    [self.weiboTableView.pullToRefreshView stopAnimating];
    
    
    NSString *sinceStr = [NSString stringWithFormat:@"%@",_since_id];
    
    ThemeLabel *counLabel = (ThemeLabel *)[self.notifyIamgeView viewWithTag:10001];
    
    if(![sinceStr isEqualToString:@"0"]){
    
        self.notifyIamgeView.hidden = NO;
        counLabel.text = [NSString stringWithFormat:@"更新了%ld条微博",visibleArr.count];
        
    
    }else{
    
        //当没有数据的时候就隐藏
        self.notifyIamgeView.hidden = YES;
        
    }
    //每次刷新完了之后就释放
    visibleArr = nil;
    
    [UIView animateWithDuration:0.35 animations:^{
        
        
        self.notifyIamgeView.transform =CGAffineTransformMakeTranslation(0, 50+60);
        
    } completion:^(BOOL finished) {
        
        [UIView animateWithDuration:0.35 delay:2 options:0 animations:^{
            
             self.notifyIamgeView.transform = CGAffineTransformIdentity;
        } completion:nil];
        
    }];
    
    if (!self.notifyIamgeView.hidden) {
        NSString *sysPath=[[NSBundle mainBundle]pathForResource:@"msgcome" ofType:@"wav"];
        
        NSURL *sysUrl=[NSURL fileURLWithPath:sysPath];
        
        AudioServicesCreateSystemSoundID((__bridge CFURLRef)sysUrl, &sounID);
        
        //    播放系统声音
        AudioServicesPlaySystemSound(sounID);

    }
   
}

#pragma mark --- 上拉加载旧的数据(已经有但是没有显示的数据)
-(void)loadDownData{
    
    //当下拉的已经没有数据的时候取最后的ID(@将MAXFLOAT数值转换为对象)
    NSNumber *max_id = @MAXFLOAT;
    
    if (self.dataList.count != 0) {
        
        //当dataList中有数据(不等于0的时候)的时候就通过下标去找到他的第一个数据
        WeiboCellLayout *layout = self.dataList.lastObject;
        
        //取到model中得ID;
        max_id = layout.model.weiboID;
        //max_id会重新调用一次最后的一条数据(减会将重复调用的数据删除掉)
        NSInteger new=[max_id integerValue]-1;
        
        max_id=[NSNumber numberWithInteger:new];
        
        
    }
    NSMutableDictionary *params = [NSMutableDictionary
                                   dictionaryWithDictionary:@{@"count": @5,@"max_id":[NSString stringWithFormat:@"%@",max_id]}];
    
    [MTServicePackage GEtWithStringURL:@"https://api.weibo.com/2/statuses/home_timeline.json" params:params headrfields:nil CompletionBlock:^(id data){
        
        //获得新的数据
        [self loadFinishDownData:data];
    }];
    
    
    
}

//上拉加载数据的方法
-(void)loadFinishDownData:(id)data{
    
    //创建可变的数组(一会存储Model中得获取的内容)
    //    NSMutableArray *dataList = [NSMutableArray array];
    
    //获得数组中的所有数据
    NSArray *array = [data objectForKey:@"statuses"];
    
    //创建一个存储新数据的可变数组
    NSMutableArray *mutableArr = [NSMutableArray array];
    
    
    //遍历数组中得数据
    for (NSDictionary *source in array) {
        
        //获得source微博正文内容
        HomeModel *model = [[HomeModel alloc]initWithDataDic:source];
        
        WeiboCellLayout *layout = [[WeiboCellLayout alloc]init];
        
        //layout获取网络中存储在model中得数据传递给weiboView中得cell
        layout.model = model;
        
        //dataList中储存的新数据
        [mutableArr addObject:layout];
        
    }
    
    //获得最新数据中得第一个数据并且将新获得的数据按顺序从上往下排列
    [self.dataList addObjectsFromArray:mutableArr];
    
//    self.dataList = mutableArr;
    
    //获取source的内容,并传递
    _weiboTableView.dataList = self.dataList;
    
    [_weiboTableView reloadData];
    
    
    //下拉停止加载数据
    [self.weiboTableView.infiniteScrollingView stopAnimating];
    
    
    
}



@end
