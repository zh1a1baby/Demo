//
//  HomeModel.m
//  SDTTinyWarmHeart
//
//  Created by mac on 16/5/25.
//  Copyright © 2016年 mac. All rights reserved.
//

#import "HomeModel.h"

@implementation HomeModel


//关键字的特殊处理
-(void)setAttributes:(NSDictionary *)dataDic{

    [super setAttributes:dataDic];
    
    id weiboId = [dataDic objectForKey:@"id"];
    
    self.weiboID = weiboId;

    NSDictionary *userModel = [dataDic objectForKey:@"user"];
    
    if (userModel) {
        
        self.user = [[UserModel alloc]initWithDataDic:userModel];
    }
    
    //转发微博
    NSDictionary *retwteedModel = [dataDic objectForKey:@"retweeted_status"];
    
    if(retwteedModel){
    
        self.retweeted_status =[[HomeModel alloc]initWithDataDic:retwteedModel];
    
        //转发的微博名字和@的微博名字
        self.retweeted_status.text = [NSString stringWithFormat:@"@%@:%@",self.retweeted_status.user.screen_name,self.retweeted_status.text];
    }
    

    

    

}



@end
