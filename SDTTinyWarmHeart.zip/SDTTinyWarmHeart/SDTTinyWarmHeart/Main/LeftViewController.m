//
//  LeftViewController.m
//  SDTTinyWarmHeart
//
//  Created by mac on 16/5/28.
//  Copyright © 2016年 mac. All rights reserved.
//

#import "LeftViewController.h"
#import "BaseNavigationController.h"
#import "SendViewController.h"
#import "MenuViewController.h"
@interface LeftViewController ()<UITableViewDataSource,UITableViewDelegate>{

    NSArray *_tableArr;



}

@end

@implementation LeftViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    UIImageView *image = [[UIImageView alloc]initWithFrame:self.view.bounds];
    
    image.image = [UIImage imageNamed:@"leftbackiamge"];
    
    [self.view addSubview:image];
    
    
    [self tableViewAction];

}

-(void)tableViewAction{

    UITableView *tableView = [[UITableView alloc]init];
    _tableView = tableView;
    tableView.frame = self.view.bounds;
    tableView.dataSource = self;
    tableView.delegate = self;
    tableView.backgroundColor =[UIColor clearColor];
    [self.view addSubview:tableView];
    
//    [tableView registerClass:[UITableView class] forCellReuseIdentifier:CellID];
    
    _tableArr = @[@"开通会员",@"我的收藏",@"我的相册",@"我的文件",@"个性装扮"];
    
    
    

}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{



    return _tableArr.count;

}



- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *cellID = @"CellID";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellID];
    
    if (cell == nil) {
        
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellID];
        
    }
    
    //表示图辅助状态(箭头)
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    NSString *str = _tableArr[indexPath.row];
    cell.textLabel.text = str;
    cell.backgroundColor = [UIColor clearColor];
    cell.textLabel.font = [UIFont systemFontOfSize:17];
    cell.textLabel.textColor = [UIColor whiteColor];
    
    return cell;

}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    tableView.backgroundColor = [UIColor clearColor];


    return 200;

}

-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{

    //创建一个新的View覆盖旧的View
    UIView *view = [[UIView alloc]initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, 200)];
    //清除View的颜色
    view.backgroundColor = [UIColor clearColor];

    UIButton *button = [UIButton buttonWithType:UIButtonTypeSystem];
    [button setTitle:@"发送微博" forState:UIControlStateNormal];
    button.tintColor = [UIColor orangeColor];
//    [button setTitleColor:[UIColor blueColor] forState:UIControlStateHighlighted];
    button.titleLabel.font = [UIFont systemFontOfSize:30];
    button.frame = CGRectMake(0, 100, 150, 30);
    [button addTarget:self action:@selector(buttonAction) forControlEvents:UIControlEventTouchUpInside];
    [view addSubview:button];

    return view;
}


-(void)buttonAction{
    SendViewController *send = [[SendViewController alloc]init];
    
    
    // 将send设置为BaseNaviga的根视图控制器
    BaseNavigationController *navigaC = [[BaseNavigationController alloc]initWithRootViewController:send];
    
    MenuViewController *menuVC = (MenuViewController *)self.view.window.rootViewController;
    
    [menuVC presentViewController:navigaC animated:YES completion:^{
        
        //当视图模态的时候隐藏
        [menuVC closeMainVC];
        
    }];

}
@end
