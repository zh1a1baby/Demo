//
//  LeftViewController.h
//  SDTTinyWarmHeart
//
//  Created by mac on 16/5/28.
//  Copyright © 2016年 mac. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LeftViewController : UIViewController

@property(strong,nonatomic)UITableView *tableView;


@end
