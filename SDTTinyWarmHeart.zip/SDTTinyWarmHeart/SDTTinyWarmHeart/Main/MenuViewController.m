//
//  MenuViewController.m
//  SDTTinyWarmHeart
//
//  Created by mac on 16/5/28.
//  Copyright © 2016年 mac. All rights reserved.
//

#import "MenuViewController.h"
#import "UIViewExt.h"
@interface MenuViewController (){

    BOOL isCanleft;

    UITableView *_tableView;
}

@end

@implementation MenuViewController

-(instancetype)initWithMainVC:(UIViewController *)mainC withLeftVC:(UIViewController *)leftVC{
    
    if (self = [super init]) {
        
        _mainVC = mainC;
        _leftVC = leftVC;
        
        [self.view addSubview: _leftVC.view];
        [self.view addSubview: _mainVC.view];
        
        _pan = [[UIPanGestureRecognizer alloc]initWithTarget:self action:@selector(panGestureRAction:)];
        _pan.enabled = NO;
        
        //加到侧滑的视图上
        [self.mainVC.view addGestureRecognizer:_pan];
        
    }
    
    //遍历_leftVC获取里面的tableView
    for (UIView *vie in leftVC.view.subviews) {
        
        if ([vie isKindOfClass:[UITableView class]]) {
            
            _tableView = (UITableView *)vie;
        }
    }
    
    //新的tableView 辅助视图的坐标
    _tableView.frame = CGRectMake(0, 0, KScreenWidth - kMainVCTranslationWidth, KScreenHeight);
    
    //TableView字体的大小
    _tableView.transform = CGAffineTransformMakeScale(0.83, 0.83);
    

    return self;
}

-(void)panGestureRAction:(UIPanGestureRecognizer *)pan{
    //是否可以
    isCanleft =YES;
    
    //sidesway侧移
    CGFloat sidesway = KScreenWidth - kMainVCTranslationWidth;
    
    
    
    //当是被侧滑移动的时候产生的X,Y点
    CGPoint point = [pan translationInView:self.view];

    if (point.x <= 0 && pan.view.left <= 0) {
        
        isCanleft =NO;
    }

    if(isCanleft && pan.view.left >= 0 &&pan.view.left <= sidesway){
    
        //计算侧滑后的坐标
        pan.view.center = CGPointMake(pan.view.center.x+point.x, pan.view.center.y);
    
        //当图片在侧滑过程中由大变小的计算
        CGFloat scale = 0.8 + 0.2 *((sidesway - point.x)/sidesway);
        
        //当移动到指定位置的时候视图最终的大小
        pan.view.transform = CGAffineTransformScale(pan.view.transform, scale, scale);
        
        [pan setTranslation:CGPointZero inView:self.view];
        
        //当视图侧滑时tableView放大缩小
        CGFloat tabScale = 1+(1-scale);
        
        _tableView.transform = CGAffineTransformScale(_tableView.transform, tabScale, tabScale);
        
        
        
        
//        if (pan.state == UIGestureRecognizerStateEnded) {
//            if (_mainVC.view.left > sidesway/2+30) {
//                
//                [self openMainVC];
//                
//            }else{
//            
//                [self closeMainVC];
//            }
        
        }
    
    if (pan.state == UIGestureRecognizerStateEnded) {
        if (_mainVC.view.left > sidesway/2+30) {
            
            [self openMainVC];
            
        }else{
            
            [self closeMainVC];
        }

        
    
    }
    
    
    


}

-(void)openMainVC{

    [UIView animateWithDuration:0.25 animations:^{
        
        
        //偏移放大缩小
        _mainVC.view.transform = CGAffineTransformMakeScale(kMainVCScale, kMainVCScale);

        
        //偏移的范围
        _mainVC.view.center = CGPointMake(KScreenWidth - kMainVCTranslationWidth+(KScreenWidth*0.8)/2, KScreenHeight/2);
        
        _tableView.transform = CGAffineTransformIdentity;
        
          }];
    
    
    
    _isOpen = YES;

}


-(void)closeMainVC{

    [UIView animateWithDuration:0.25 animations:^{
        
        _mainVC.view.transform = CGAffineTransformIdentity;
        
        _mainVC.view.center = self.view.center;
        
        _tableView.transform = CGAffineTransformMakeScale(0.83, 0.83);
    }];

    _isOpen = NO;


}


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}


@end
