//
//  WeibobrowView.m
//  SDTTinyWarmHeart
//
//  Created by mac on 16/6/1.
//  Copyright © 2016年 mac. All rights reserved.
//

#import "WeibobrowView.h"
#define Kitmes_size (KScreenWidth/7)
#define KFace_size (Kitmes_size - 20)
@interface WeibobrowView (){
   
    UIImageView *_managerView;//放大镜
    UIImageView *_faceImageView;//表情放大
    NSString *_imageName;

}

@end

@implementation WeibobrowView

-(instancetype)initWithFrame:(CGRect)frame{


    if (self = [super initWithFrame:frame]) {
        
      
        
        _managerView = [[UIImageView alloc]initWithFrame:CGRectMake(100, 50, 64, 92)];
        
        _managerView.image = [UIImage imageNamed:@"emoticon_keyboard_magnifier"];
        
        //视图显示是先隐藏图片
        _managerView.hidden = YES;
        
        [self addSubview:_managerView];
        
        _faceImageView=[[UIImageView alloc]initWithFrame:CGRectMake((_managerView.width-45)/2, 10, 45, 45)];
        
        [_managerView addSubview:_faceImageView];
        
        //加载数据
        [self loadData];
        
        
    }

    return self;


}

#pragma mark --- 加载数据
-(void)loadData{
    
    //获取plist中得数据
    NSString *paht = [[NSBundle mainBundle]pathForResource:@"emoticons" ofType:@"plist"];
    
    NSArray *pahtArr = [NSArray arrayWithContentsOfFile:paht];
    
    //大数组
    _mutableArr = [NSMutableArray array];
    
    //小数组
    NSMutableArray *itmes = [NSMutableArray array];
    
    //在大数据中添加小数组
    [_mutableArr addObject:itmes];
    
    for (int i = 0; i < pahtArr.count; i++) {
        
        
        if (itmes.count == 28) {
            
            //当小数组中满28个元素之后就会创建一个新的小数组
            itmes = [NSMutableArray arrayWithCapacity:28];
            
            [_mutableArr addObject:itmes];
                     
        }
        
        //获取plist大数组中得数据
        [itmes addObject:pahtArr[i]];
        
    }
    
    //表情视图固定
    CGRect frame = self.frame;
    frame.size.width = KScreenWidth * 4;
    frame.size.height = Kitmes_size * 4;
    self.frame = frame;
    
    
}
-(void)drawRect:(CGRect)rect{

//     CGContextRef contextRef = UIGraphicsGetCurrentContext();


    int colum = 0;//列 7
    int row = 0;//行 4
    
    for (int i = 0; i < _mutableArr.count; i++) {
        
        NSArray *itmes = [_mutableArr objectAtIndex:i];
        
        for (int j = 0; j <itmes.count ; j++) {
            
            NSDictionary *dic = itmes[j];
            
            NSString *imageStr = dic[@"png"];
          
            
            UIImage *image = [UIImage imageNamed:imageStr];
            
            
            //表情的坐标
            CGFloat x;
            CGFloat y;
            
            //间距
            x = colum * Kitmes_size+(Kitmes_size - KFace_size)/2 + i * KScreenWidth;
            y = row * Kitmes_size +(Kitmes_size - KFace_size)/2;
            
            colum++;
            
            if (colum %7 == 0) {
                
                colum = 0;
                row++;
            }
            if (row %4 == 0) {
                
                row = 0;
            }
            
            
            //将表情画到视图上
            [image drawInRect:CGRectMake(x, y,KFace_size, KFace_size)];

            
            }
        }

}

-(void)setMagnifierView:(CGPoint)point{

    //当前的页码
    NSInteger paht = point.x/KScreenWidth;

    int column =(point.x - paht*KScreenWidth)/Kitmes_size;
    int row =point.y/Kitmes_size;
    
    CGFloat x = Kitmes_size *column +Kitmes_size +paht*KScreenWidth;
    CGFloat y = Kitmes_size *row +Kitmes_size/2;
    
    _managerView.center =CGPointMake(x, 0);
    _managerView.bottom = y;
    
    NSArray *arr = _mutableArr[paht];
    //表情下表的位置
    NSInteger index = row * 7+column;
    
    if(index >= arr.count){
    
    
        _managerView.hidden = YES;
        
        return;
    }
    
    //小字典
    NSDictionary *dic = [arr objectAtIndex:index];
    NSString *imageStr = [dic objectForKey:@"png"];
    
    _imageName = dic[@"chs"];
    UIImage *image = [UIImage imageNamed:imageStr];
    _faceImageView.image = image;
    
    
  }


//开始触摸
-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{

    if ([self.superview isKindOfClass:[UIScrollView class]]) {
        
        UIScrollView *scrollView = (UIScrollView *)self.superview;
        
        //开启滑动
        scrollView.scrollEnabled = NO;
        
    }

    
    
    
    UITouch *touch = [touches anyObject];

    CGPoint point = [touch locationInView:self];
    
    _managerView.hidden = NO;
    [self setMagnifierView:point];


}
//触摸移动
-(void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{

    UITouch *touch = [touches anyObject];
    
    CGPoint point = [touch locationInView:self];
    
    _managerView.hidden = NO;
    [self setMagnifierView:point];



}
//触摸结束
-(void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{

//当试图上又ScollView的时候
    if ([self.superview isKindOfClass:[UIScrollView class]]) {
        
        UIScrollView *scrollView = (UIScrollView *)self.superview;
        
        //开启滑动
        scrollView.scrollEnabled = YES;
        
    }
    
    
    if ([self.delegate respondsToSelector:@selector(sendFaceName:)]){
        
        
        [self.delegate sendFaceName:_imageName];
    

    }
    
    _managerView.hidden = YES;

}

@end
