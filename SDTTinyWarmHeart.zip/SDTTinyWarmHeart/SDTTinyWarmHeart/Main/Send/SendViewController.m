//
//  SendViewController.m
//  SDTTinyWarmHeart
//
//  Created by mac on 16/5/29.
//  Copyright © 2016年 mac. All rights reserved.
//

#import "SendViewController.h"
#import "MTServicePackage.h"
#import "UIViewExt.h"

#import <CoreLocation/CoreLocation.h>

@interface SendViewController ()<UIImagePickerControllerDelegate,UINavigationControllerDelegate,CLLocationManagerDelegate,SendFaceNameProtocol>{

    UIView *_toolBar;//工具栏

    NSData *_imageData;//保存选中的图片
    UIImageView *_imageView;//选中的图片视图
    
    UILabel *_locationLabel;//定位信息
    CLLocationManager *_manager;
    
    CLLocationCoordinate2D _coordinate;
    CLGeocoder *_coder;//编码对象
    
}

@end

@implementation SendViewController


- (WeiboFacePanelView *)facePanelView {

    if (!_facePanelView) {
        
        _facePanelView = [[WeiboFacePanelView alloc]initWithFrame:CGRectMake(0, KScreenHeight, 0, 0)];
        [self.view addSubview:_facePanelView];
        
        _facePanelView.faceView.delegate = self;
    }
    
    return _facePanelView;

}


- (void)viewDidLoad {
    [super viewDidLoad];
    
    //键盘将要弹出
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(keyboardCenter:) name:UIKeyboardDidShowNotification object:nil];
    
//    //键盘将要消失
//    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(keyboardCenter:) name:UIKeyboardDidHideNotification object:nil];
//    //键盘高度改变
//    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(keyboardCenter:) name:UIKeyboardDidChangeFrameNotification object:nil];
//    
    
    
    ThemeButton *button = [[ThemeButton alloc]initWithFrame:CGRectMake(0, 0, 44, 44)];
    [button addTarget:self action:@selector(buttonAction) forControlEvents:UIControlEventTouchUpInside];
    button.imageName = @"button_icon_ok.png";
    //将button添加到导航栏
    UIBarButtonItem *barButton = [[UIBarButtonItem alloc]initWithCustomView:button];
    self.navigationItem.rightBarButtonItem = barButton;
    
    
    ThemeButton *button1 = [[ThemeButton alloc]initWithFrame:CGRectMake(0, 0, 44, 44)];
    [button1 addTarget:self action:@selector(cancelAction) forControlEvents:UIControlEventTouchUpInside];
    button1.imageName = @"button_icon_close.png";
    //将button添加到导航栏
    UIBarButtonItem *barButton1 = [[UIBarButtonItem alloc]initWithCustomView:button1];
    self.navigationItem.leftBarButtonItem = barButton1;
    _myTextView.backgroundColor = [UIColor clearColor];
    
    //工具栏
    [self creatToolBar];

}
#pragma mark --- 第一响应者
-(void)viewWillAppear:(BOOL)animated{
    
    [super viewWillAppear:animated];
    
    //成为第一响应者
    [self.myTextView becomeFirstResponder];

}

//视图将要消失的时候
-(void)viewWillDisappear:(BOOL)animated{
    
    [super viewWillDisappear:animated];
    
    //取消第一响应者
    [self.myTextView resignFirstResponder];
    
}


#pragma mark --- 代理点击方法(模态返回)
-(void)buttonAction{

    [self dismissViewControllerAnimated:YES completion:nil];
    [self sendAction];
    
}

-(void)cancelAction{

    [self dismissViewControllerAnimated:YES completion:nil];

}


#pragma mark --- 发送微博请求
-(void)sendAction{
    
//    NSString *str = [[NSUserDefaults standardUserDefaults]objectForKey:KAccess_token_ID];
    
    
//    NSMutableDictionary *params = [NSMutableDictionary dictionaryWithDictionary:@{@"access_token":str, @"status":_myTextView.text}];
//    
////    NSData *imageData = [NSData dataWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"002" ofType:@"jpeg"]];
//    
//    [MTServicePackage POSTWithStringURL:@"https://upload.api.weibo.com/2/statuses/upload.json" params:params headrfields:nil bodyData:nil CompletionBlock:^(id data) {
//        
//        NSLog(@"上传成功");
//        
//    }];

    
    
    NSString *status=self.myTextView.text;
    
    NSMutableDictionary *params=[NSMutableDictionary dictionaryWithDictionary:@{@"status":status}];
    
    if (_coordinate.latitude != 0 ) {
        
        [params setObject:[NSString stringWithFormat:@"%lf",_coordinate.latitude] forKey:@"lat"];
        
        [params setObject:[NSString stringWithFormat:@"%lf",_coordinate.longitude] forKey:@"long"];
        
    }
    
    
    
    if (_imageData==nil) {
        [MTServicePackage POSTWithStringURL:@"https://api.weibo.com/2/statuses/update.json" params:params headrfields:nil bodyData:nil CompletionBlock:^(id data) {
            
//            NSLog(@"%@",data);
        }];
        
    }else{
        
        [MTServicePackage POSTWithStringURL:@"https://upload.api.weibo.com/2/statuses/upload.json" params:params headrfields:nil bodyData:_imageData CompletionBlock:^(id data) {
          
            
        }];
    }


}

#pragma mark ---  通知方法(获取键盘的高度)
-(void)keyboardCenter:(NSNotification*)not{
    
    /**
     {
     UIKeyboardAnimationCurveUserInfoKey 曲线动画类型
     UIKeyboardAnimationDurationUserInfoKey = "0.4"; 动画持续时间
     UIKeyboardBoundsUserInfoKey = "NSRect: {{0, 0}, {320, 253}}";键盘的尺寸
     UIKeyboardCenterBeginUserInfoKey = "NSPoint: {160,
     1009.5}";键盘的初始中心点坐标
     UIKeyboardCenterEndUserInfoKey = "NSPoint: {160, 441.5}";键盘显示时中心点坐标
     UIKeyboardFrameBeginUserInfoKey = "NSRect: {{0, 883}, {320,
     253}}";键盘初始时frame
     UIKeyboardFrameEndUserInfoKey = "NSRect: {{0, 315}, {320,
     253}}";键盘显示时frame
     UIKeyboardIsLocalUserInfoKey = 1;
     }
     
     */

    //获得键盘高度
    CGRect frame = [[not.userInfo objectForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue];
    
    CGFloat keyHeight = CGRectGetHeight(frame);
    
    //键盘高度
    self.layoutC.constant =keyHeight+75;
    
    CGFloat duration = [[not.userInfo objectForKey:UIKeyboardAnimationDurationUserInfoKey] doubleValue];
    
    
    NSInteger option = [[not.userInfo objectForKey:UIKeyboardAnimationCurveUserInfoKey] integerValue];
    
    [UIView animateKeyframesWithDuration:duration delay:0 options:option animations:^{
        
        // 对约束布局调用此方法
        [self.view layoutIfNeeded];
        
    } completion:nil];
    
    //判断键盘收回
    if ([not.name isEqualToString:UIKeyboardFrameEndUserInfoKey]) {
        
        
        self.layoutC.constant = 0;
        
    }
    
    _toolBar.top = self.myTextView.bottom;
    
    
    if (self.navigationController.navigationBar.translucent) {
        
        self.myTextView.height = KScreenHeight - keyHeight - _toolBar.height - 64;
        
    }else {
    
        self.myTextView.height = KScreenHeight - keyHeight - _toolBar.height ;
        

    
    
    }
    
    _imageView = [[UIImageView alloc]initWithFrame:CGRectMake(KScreenWidth -65, 1, 60, 50)];
    
    [_toolBar addSubview:_imageView];
    
    
    
    
    
}

#pragma mark --- 工具栏
-(void)creatToolBar{

    _toolBar = [[UIView alloc]initWithFrame:CGRectMake(0, 0, KScreenWidth, 75)];
    
    [self.view addSubview:_toolBar];
    
    NSArray *arr = @[
                     @"compose_toolbar_1.png",
                     @"compose_toolbar_3.png",
                     @"compose_toolbar_4.png",
                     @"compose_toolbar_5.png",
                     @"compose_toolbar_6.png"
                     ];


    for (int i = 0; i <arr.count; i++) {
        
        ThemeButton *button = [[ThemeButton alloc]initWithFrame:CGRectMake(i*50, 10, 50, 50)];
        
        [button addTarget:self action:@selector(ThemeButtonAction:) forControlEvents:UIControlEventTouchUpInside];
        
        button.tag = 7000+i;
        NSString *buttonStr = arr[i];
        button.imageName = buttonStr;
        [_toolBar addSubview:button];
        
        
    }
    
    //定位用户信息
    _locationLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, KScreenWidth, 20)];
    
    _locationLabel.font = [UIFont systemFontOfSize:15];
    
   
    [_toolBar addSubview:_locationLabel];
    
    

}

-(void)ThemeButtonAction:(ThemeButton *)button{

    if (button.tag == 7000) {
        
        [self selectedImage];
    }else if (button.tag == 7003){
    
        [self locationManager];
    }else if(button.tag == 7004){
        
        
        if ([self.myTextView isFirstResponder]) {
            
            
            [self showFacePanelView];
            
        } else {
            
            [self hideFacePanelView];
        
        
        }
    
    }else{
        [self hideFacePanelView];
    
    }

}

#pragma mark --- 显示隐藏表情栏
-(void)showFacePanelView{
    
    //  收齐键盘
    [self.myTextView resignFirstResponder];
    
    [UIView animateWithDuration:.35 animations:^{
        
        if (self.navigationController.navigationBar.translucent) {
            self.facePanelView.transform=CGAffineTransformMakeTranslation(0, -self.facePanelView.height);
            
            _toolBar.bottom=self.facePanelView.top;
            
            _myTextView.height=KScreenHeight-self.facePanelView.height-_toolBar.height;
            
        }else{
            
            self.facePanelView.transform=CGAffineTransformMakeTranslation(0, -self.facePanelView.height - 64);
            
            
            _toolBar.bottom=self.facePanelView.top;
            
            _myTextView.height=KScreenHeight-self.facePanelView.height-_toolBar.height;
        }
        
    }];
    

}
-(void)hideFacePanelView{
    //成为第一响应者
    [_myTextView becomeFirstResponder];

    [UIView animateWithDuration:0.35 animations:^{
       
        self.facePanelView.transform = CGAffineTransformIdentity;
        
    }];


}

//定位服务管理
-(void)locationManager{

    
    if (!_manager) {
    
        //设置定位精度
        _manager = [[CLLocationManager alloc]init];
        
        _manager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters;
        
        _manager.delegate = self;
    }
    //判断定位服务是否打开
    if([CLLocationManager locationServicesEnabled]){
    
    
    }else{
    
        NSLog(@"定位未开启");
    }
       //请求用户授权
        
        [_manager requestWhenInUseAuthorization];
        [_manager requestAlwaysAuthorization];
    

    //停止授权
    [_manager startUpdatingLocation];

}
#pragma  mark --- 定位信息
-(void)locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray<CLLocation *> *)locations{

    CLLocation *location = [locations lastObject];
    
    _coordinate = location.coordinate;
    

    //信息反编码
    if (!_coder) {
        //创建编码对象
        _coder = [[CLGeocoder alloc]init];
    }
    
    //编码39.9080074220,116.3975517341
    [_coder reverseGeocodeLocation:location completionHandler:^(NSArray<CLPlacemark *> * _Nullable placemarks, NSError * _Nullable error) {
       
        CLPlacemark *placemark = [placemarks lastObject];
        
        //获取街道信息(Key)
        NSString *street = [placemark.addressDictionary objectForKey:@"Street"];
        
        //异步获取街道信息
        dispatch_async(dispatch_get_main_queue(), ^{
            
            _locationLabel.text = street;
        });
        
    }];

    //停止定位 , 可以节省用电.
    [_manager stopUpdatingLocation];
    
    
}


#pragma mark --- 选取工具栏照片
-(void)selectedImage{
    
    //获取自带相机中得照片
    UIImagePickerController *pick = [[UIImagePickerController alloc]init];

    //选取媒体方式
    pick.sourceType = UIImagePickerControllerSourceTypeSavedPhotosAlbum;
    //代理
    pick.delegate = self;
    [self presentViewController:pick animated:YES completion:nil];


}

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *,id> *)info{

    [self dismissViewControllerAnimated:YES completion:nil];
    
    UIImage *image = [info objectForKey:UIImagePickerControllerOriginalImage];
    
    //0.2图片的尺寸大小
    _imageData = UIImageJPEGRepresentation(image, 0.2);

    _imageView.image = image;

}

#pragma mark --- 代理协议方法
-(void)sendFaceName:(NSString *)faceName{
    
    _myTextView.text=[_myTextView.text stringByAppendingString:faceName];
    
}



@end
