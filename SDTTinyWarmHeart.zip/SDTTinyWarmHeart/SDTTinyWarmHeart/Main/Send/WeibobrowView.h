//
//  WeibobrowView.h
//  SDTTinyWarmHeart
//
//  Created by mac on 16/6/1.
//  Copyright © 2016年 mac. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol SendFaceNameProtocol <NSObject>
//可选择实现的代理方法

-(void)sendFaceName:(NSString *)faceName;


@end


@interface WeibobrowView : UIView


@property(strong ,nonatomic) NSMutableArray *mutableArr;

@property(nonatomic,weak)id<SendFaceNameProtocol> delegate;

@end
