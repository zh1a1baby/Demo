//
//  WeiboFacePanelView.h
//  SDTTinyWarmHeart
//
//  Created by mac on 16/6/1.
//  Copyright © 2016年 mac. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "WeibobrowView.h"
@interface WeiboFacePanelView : UIView

@property(nonatomic,strong)WeibobrowView *faceView;


@end
