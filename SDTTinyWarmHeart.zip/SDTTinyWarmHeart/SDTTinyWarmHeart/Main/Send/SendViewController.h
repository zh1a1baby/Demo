//
//  SendViewController.h
//  SDTTinyWarmHeart
//
//  Created by mac on 16/5/29.
//  Copyright © 2016年 mac. All rights reserved.
//

#import "BaseViewController.h"
#import "WeiboFacePanelView.h"
@interface SendViewController : BaseViewController
//成为第一响应者
@property (weak, nonatomic) IBOutlet UITextView *myTextView;
//获取键盘的高度(连线底部的限制)
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *layoutC;

@property(nonatomic,strong)WeiboFacePanelView *facePanelView;

@end
