//
//  MenuViewController.h
//  SDTTinyWarmHeart
//
//  Created by mac on 16/5/28.
//  Copyright © 2016年 mac. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MenuViewController : UIViewController

//获取侧滑的视图与主视图控制器
-(instancetype)initWithMainVC:(UIViewController *)mainVC withLeftVC:(UIViewController *)leftVC;

//子视图控制器公开属性，在其他视图控制器可以方便获得
@property (strong,nonatomic)UIViewController *mainVC;
@property (strong,nonatomic)UIViewController *leftVC;

@property (nonatomic)BOOL isOpen;//判断视图是否处于打开状态;

//滑动手势
@property(strong,nonatomic)UIPanGestureRecognizer *pan;//侧滑
@property(strong,nonatomic)UITapGestureRecognizer *tap;//打开之后

//显示侧栏与隐藏侧栏的公开方法
-(void)openMainVC;
-(void)closeMainVC;


@end
