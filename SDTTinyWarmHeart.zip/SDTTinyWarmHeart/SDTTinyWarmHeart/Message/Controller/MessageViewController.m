//
//  MessageViewController.m
//  SDTTinyWarmHeart
//
//  Created by mac on 16/5/21.
//  Copyright © 2016年 mac. All rights reserved.
//

#import "MessageViewController.h"
#import "WeiboFacePanelView.h"
@interface MessageViewController ()

@end

@implementation MessageViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.automaticallyAdjustsScrollViewInsets = NO;
       
    WeiboFacePanelView *weiboFace =[[WeiboFacePanelView alloc]initWithFrame:CGRectMake(0, 100, 0, 0)];
    weiboFace.backgroundColor = [UIColor clearColor];
    
    [self.view addSubview:weiboFace];
    
    
}



@end
